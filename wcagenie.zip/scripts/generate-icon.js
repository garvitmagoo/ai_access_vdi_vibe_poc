// Generates icon.png for the WCAGenie extension.
// Renders an inline SVG (a magic genie lamp granting a WCAG "wish" sparkle)
// to a 256x256 PNG using @resvg/resvg-js (prebuilt, no native build tools).
//
// Run with: npm run gen-icon

const { Resvg } = require('@resvg/resvg-js');
const fs = require('fs');
const path = require('path');

const size = 256;

const svg = `
<svg width="${size}" height="${size}" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="256" y2="256" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#6D28D9"/>
      <stop offset="0.55" stop-color="#4338CA"/>
      <stop offset="1" stop-color="#0A6BD8"/>
    </linearGradient>
    <radialGradient id="glow" cx="128" cy="120" r="96" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#FFFFFF" stop-opacity="0.18"/>
      <stop offset="1" stop-color="#FFFFFF" stop-opacity="0"/>
    </radialGradient>
  </defs>

  <!-- Background -->
  <rect width="256" height="256" rx="56" fill="url(#bg)"/>

  <!-- Soft central glow -->
  <circle cx="128" cy="120" r="96" fill="url(#glow)"/>

  <!-- Ambient magic stars -->
  <circle cx="54" cy="70" r="2.5" fill="#FFFFFF" opacity="0.6"/>
  <circle cx="210" cy="188" r="2.5" fill="#FFFFFF" opacity="0.55"/>
  <circle cx="44" cy="176" r="2" fill="#FFFFFF" opacity="0.45"/>

  <!-- Universal accessibility figure inside a ring -->
  <circle cx="128" cy="122" r="66" fill="none" stroke="#FFFFFF" stroke-width="9" stroke-opacity="0.9"/>
  <g fill="#FFFFFF">
    <!-- Head -->
    <circle cx="128" cy="82" r="13"/>
  </g>
  <g fill="none" stroke="#FFFFFF" stroke-width="15" stroke-linecap="round">
    <!-- Outstretched arms -->
    <path d="M86 112 L170 112"/>
    <!-- Splayed legs -->
    <path d="M128 110 L108 170"/>
    <path d="M128 110 L148 170"/>
  </g>

  <!-- Genie magic: granted-wish sparkle -->
  <path d="M198 44 L204 57 L217 63 L204 69 L198 82 L192 69 L179 63 L192 57 Z" fill="#FFFFFF"/>
  <path d="M212 108 L215 116 L223 119 L215 122 L212 130 L209 122 L201 119 L209 116 Z" fill="#FFFFFF" opacity="0.85"/>
</svg>
`;

const resvg = new Resvg(svg, { fitTo: { mode: 'width', value: size } });
const png = resvg.render().asPng();

const outPath = path.join(__dirname, '..', 'icon.png');
fs.writeFileSync(outPath, png);
console.log(`Icon written to ${outPath} (${png.length} bytes)`);
