# Changelog

All notable changes to **WCAGenie** are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-07-16

First public release. WCAGenie catches WCAG 2.1 AA violations in
React/JSX/TSX and HTML as you type, and helps you fix them with deterministic
quick fixes, AI-assisted fixes, and a screen-reader preview.

### Added

#### Scanning & diagnostics

- **AST-based accessibility scanning** for `.jsx`, `.tsx`, `.js`, `.ts`, and `.html` files.
- **26 built-in WCAG 2.1 rules** covering images, buttons, form labels, ARIA roles and
  attributes, heading order, color contrast, keyboard interaction, autocomplete, links,
  media, duplicate IDs, `target="_blank"` safety, and more.
- **Real-time diagnostics** with debounced re-scanning on edit, plus scan-on-open and
  scan-on-save (both toggleable).
- **Accessibility score** (0–100) in the status bar with a severity breakdown tooltip.
- **WCAG metadata** on every diagnostic — each issue links to its WCAG criterion and the
  corresponding axe-core documentation.

#### Fixes

- **Deterministic quick fixes** for every rule via VS Code Code Actions, each annotated
  with a confidence score and risk reasoning.
- **Static Fix Current File** and **Static Fix Workspace** with a risk-aware preview panel
  (confidence distribution, "Select Safe Only", and confirmation before applying risky changes).
- **AI-powered fixes** — single-issue, whole-file (`AI Fix Entire File`), and
  **Bulk AI Fix Workspace**, each shown in a diff preview with confidence, reasoning, and
  axe-core metadata before anything is written.
- **Safety validation** before writing — fixes are checked for overlapping ranges, source
  drift, and JSX syntax validity, so a bad suggestion cannot corrupt your source.
- **In-memory fix caching** (10-minute TTL) to keep AI usage low; cleared automatically when
  the AI provider or model changes.

#### AI providers

- **GitHub Copilot** via the VS Code Language Model API — no API key required.
- **OpenAI**, **Azure OpenAI**, and **Anthropic Claude** via API key.
- **Secure key storage** using VS Code SecretStorage (`WCAGenie: Set AI API Key`).
- **Resilient requests** — retries with exponential backoff, `Retry-After` support, and a
  request timeout; per-file failures never abort a bulk run.

#### Tooling & reports

- **Screen Reader Preview** with simulated announcements and voice playback (play all,
  per-row play, stop, voice selector, speed slider).
- **Accessibility Report** panel (current file or whole workspace) with click-to-navigate.
- **Export Report** to JSON for CI/CD and dashboards.
- **Generate A11y Unit Tests** — creates targeted `jest-axe` / Testing Library tests and
  checks for the required testing packages.
- **Visual Settings panel** (`WCAGenie: Open Settings`) to configure provider, rules,
  exclude patterns, and performance without editing JSON.
- **Project configuration** via `.a11yrc.json` (enable/disable rules, exclude files),
  respected across diagnostics, reports, and exports.
- **Tailwind-aware color-contrast** suggestions.
- **Keyboard shortcuts** — `Ctrl+Alt+R` (report) and `Ctrl+Alt+F` (static fix current file).

### Security

- Webview panels use a strict Content-Security-Policy with a cryptographically random nonce.
- All file, user, and AI-generated content is HTML-escaped before rendering in webviews.
- Webview commands are restricted to a known allowlist and file-open handlers verify
  workspace containment.

[1.0.0]: https://github.com/garvitmagoo/wcagenie/releases/tag/v1.0.0
