# Quick Publishing Guide

## 🔷 Push to GitHub

```bash
cd /Users/neha/Desktop/wcagenie

# Add remote (if not already added)
git remote add origin https://github.com/garvitmagoo/wcagenie.git

# Push to GitHub
git push -u origin main
```

Verify: https://github.com/garvitmagoo/wcagenie

---

## 📦 Publish to VS Code Marketplace

### 1. Get Publisher Account & PAT Token

- Go to: https://dev.azure.com
- Create personal access token with "Marketplace (Manage)" scope
- Copy and save the token

### 2. Install VSCE

```bash
npm install -g @vscode/vsce
```

### 3. Build & Publish

```bash
cd /Users/neha/Desktop/wcagenie

# Build extension
npm run package

# Publish to marketplace
vsce publish -p YOUR_PAT_TOKEN_HERE
```

### 4. Verify

- Search "WCAGenie" in VS Code Extensions
- Or visit: https://marketplace.visualstudio.com/items?itemName=garvitmagoo.wcagenie

---

## 📝 For Future Versions

```bash
# Update version in package.json
# Then:

npm run package
vsce publish -p YOUR_PAT_TOKEN_HERE
```

---

**That's it!** Your extension is published. 🚀

