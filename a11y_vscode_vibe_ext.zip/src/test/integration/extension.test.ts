import * as assert from 'assert';
import * as vscode from 'vscode';

suite('Extension Integration Tests', () => {
  const extensionId = 'lockton.a11y-scanner';

  test('extension should be present', () => {
    const ext = vscode.extensions.getExtension(extensionId);
    assert.ok(ext, 'Extension not found');
  });

  test('extension should activate on TSX file', async () => {
    const ext = vscode.extensions.getExtension(extensionId);
    assert.ok(ext, 'Extension not found');

    // Create a TSX file to trigger activation
    const doc = await vscode.workspace.openTextDocument({
      language: 'typescriptreact',
      content: '<img src="test.png" />',
    });
    await vscode.window.showTextDocument(doc);

    // Wait for extension to activate
    await ext.activate();
    assert.ok(ext.isActive, 'Extension should be active');
  });

  test('commands should be registered', async () => {
    const commands = await vscode.commands.getCommands(true);
    const a11yCommands = commands.filter(c => c.startsWith('a11y.'));

    assert.ok(a11yCommands.includes('a11y.scanCurrentFile'), 'scanCurrentFile command missing');
    assert.ok(a11yCommands.includes('a11y.scanWorkspace'), 'scanWorkspace command missing');
    assert.ok(a11yCommands.includes('a11y.showReport'), 'showReport command missing');
    assert.ok(a11yCommands.includes('a11y.screenReaderPreview'), 'screenReaderPreview missing');
    assert.ok(a11yCommands.includes('a11y.setApiKey'), 'setApiKey command missing');
    assert.ok(a11yCommands.includes('a11y.generateTests'), 'generateTests command missing');
    assert.ok(a11yCommands.includes('a11y.exportSarif'), 'exportSarif command missing');
    assert.ok(a11yCommands.includes('a11y.exportJson'), 'exportJson command missing');
  });

  test('diagnostics should appear for inaccessible code', async () => {
    const doc = await vscode.workspace.openTextDocument({
      language: 'typescriptreact',
      content: '<img src="broken.png" />',
    });
    await vscode.window.showTextDocument(doc);

    // Run scan command
    await vscode.commands.executeCommand('a11y.scanCurrentFile');

    // Give diagnostics time to populate
    await new Promise(resolve => setTimeout(resolve, 500));

    const diagnostics = vscode.languages.getDiagnostics(doc.uri)
      .filter(d => d.source === 'A11y Scanner');

    assert.ok(diagnostics.length > 0, 'Should have at least one diagnostic');
    assert.ok(
      diagnostics.some(d => d.code === 'img-alt'),
      'Should flag img-alt rule',
    );
  });
});
