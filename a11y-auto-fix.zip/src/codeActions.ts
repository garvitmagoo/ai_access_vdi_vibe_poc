import * as vscode from 'vscode';
import { getAiFix } from './ai/provider';
import type { A11yChange, FullFileFixResult } from './ai/fullFileFix';
import { BulkFixPreviewPanel } from './webview/bulkFixPreviewPanel';
import type { BulkFixFileEntry } from './webview/bulkFixPreviewPanel';
import { DiffPreviewPanel } from './webview/diffPreviewPanel';
import { getDiagnosticData } from './diagnostics';
import { scanForA11yIssues } from './scanner/astScanner';
import { loadConfig, applyConfig } from './config';
import { toVscodeSeverity } from './types';
import { VALID_ROLES } from './scanner/rules/ariaRole';
import { suggestAccessibleForeground } from './scanner/rules/colorContrast';
import { validateFix, getWcagTags, getHelpUrl, getStaticFixRisk, type StaticFixRisk } from './scanner/axeIntegration';

/**
 * Find the closing `>` or `/>` of an opening JSX tag on a line,
 * scanning forward from `tagStart` (the `<` position).
 * Skips over quoted strings and `{...}` JSX expressions so we
 * never match a `>` that lives inside an attribute value.
 *
 * Returns the index of `/` for self-closing `/>`, or the index of `>`
 * for a normal open tag. Returns -1 if the tag doesn't close on this line.
 */
function findOpeningTagClose(lineText: string, tagStart: number): number {
  let i = tagStart;

  // Skip '<'
  if (i < lineText.length && lineText[i] === '<') { i++; }

  // Skip tag name  (letters, digits, dots, dashes, underscores)
  while (i < lineText.length && /[a-zA-Z0-9._\-]/.test(lineText[i])) { i++; }

  // Walk through attributes, skipping strings and {expressions}
  let inString: string | false = false;
  let braceDepth = 0;

  while (i < lineText.length) {
    const ch = lineText[i];

    if (inString) {
      if (ch === inString && lineText[i - 1] !== '\\') {
        inString = false;
      }
    } else if (ch === '"' || ch === "'") {
      inString = ch;
    } else if (ch === '{') {
      braceDepth++;
    } else if (ch === '}') {
      braceDepth = Math.max(0, braceDepth - 1);
    } else if (braceDepth === 0) {
      // Self-closing />
      if (ch === '/' && i + 1 < lineText.length && lineText[i + 1] === '>') {
        return i;
      }
      // Normal close >
      if (ch === '>') {
        return i;
      }
    }

    i++;
  }

  return -1; // tag doesn't close on this line
}

/**
 * Find the closing `>` or `/>` of a JSX opening tag that may span multiple lines.
 * Returns { line, column } of the insertion point (just before `>` or `/>`)
 * or null if not found within a reasonable range (20 lines).
 */
function findOpeningTagCloseMultiline(
  document: vscode.TextDocument,
  startLine: number,
  tagStartCol: number,
): { line: number; column: number } | null {
  let inString: string | false = false;
  let braceDepth = 0;
  let pastTagName = false;
  const maxLine = Math.min(startLine + 20, document.lineCount - 1);

  for (let lineNum = startLine; lineNum <= maxLine; lineNum++) {
    const lineText = document.lineAt(lineNum).text;
    const startCol = lineNum === startLine ? tagStartCol : 0;

    for (let i = startCol; i < lineText.length; i++) {
      const ch = lineText[i];

      // Skip past `<TagName` on the first line
      if (!pastTagName) {
        if (ch === '<') { continue; }
        if (/[a-zA-Z0-9._\-]/.test(ch)) { continue; }
        pastTagName = true;
      }

      if (inString) {
        if (ch === inString && (i === 0 || lineText[i - 1] !== '\\')) {
          inString = false;
        }
      } else if (ch === '"' || ch === "'") {
        inString = ch;
      } else if (ch === '{') {
        braceDepth++;
      } else if (ch === '}') {
        braceDepth = Math.max(0, braceDepth - 1);
      } else if (braceDepth === 0) {
        if (ch === '/' && i + 1 < lineText.length && lineText[i + 1] === '>') {
          return { line: lineNum, column: i };
        }
        if (ch === '>') {
          return { line: lineNum, column: i };
        }
      }
    }
  }

  return null;
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0) as number[]);
  for (let i = 0; i <= m; i++) { dp[i][0] = i; }
  for (let j = 0; j <= n; j++) { dp[0][j] = j; }
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

/**
 * Find the closest valid ARIA role by Levenshtein distance.
 */
function findClosestRole(invalid: string): string | null {
  let best: string | null = null;
  let bestDist = Infinity;
  for (const role of VALID_ROLES) {
    const dist = levenshtein(invalid, role);
    if (dist < bestDist) {
      bestDist = dist;
      best = role;
    }
  }
  // Only suggest if distance is reasonable (≤ half the length of the input)
  if (best && bestDist <= Math.max(3, Math.ceil(invalid.length / 2))) {
    return best;
  }
  return null;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Provides Quick Fix code actions for accessibility diagnostics.
 * When the user clicks the lightbulb on an a11y issue, this provider
 * offers an AI-powered fix and/or a manual fix suggestion.
 */
export class A11yCodeActionProvider implements vscode.CodeActionProvider {

  public static readonly providedCodeActionKinds = [
    vscode.CodeActionKind.QuickFix,
  ];

  async provideCodeActions(
    document: vscode.TextDocument,
    _range: vscode.Range,
    context: vscode.CodeActionContext,
  ): Promise<vscode.CodeAction[]> {
    const actions: vscode.CodeAction[] = [];

    for (const diagnostic of context.diagnostics) {
      if (diagnostic.source !== 'A11y Scanner') {
        continue;
      }

      // Add a manual/static quick fix based on the rule
      const staticFix = this.getStaticFix(document, diagnostic);
      if (staticFix) {
        actions.push(staticFix);
      }

      // Add an AI-powered fix option
      const config = vscode.workspace.getConfiguration('a11y');
      if (config.get<string>('aiProvider', 'none') !== 'none') {
        const aiFix = new vscode.CodeAction(
          `A11y: AI Fix - ${diagnostic.message}`,
          vscode.CodeActionKind.QuickFix,
        );
        aiFix.diagnostics = [diagnostic];
        aiFix.command = {
          command: 'a11y.applyAiFix',
          title: 'Apply AI Accessibility Fix',
          arguments: [document.uri, diagnostic],
        };
        actions.push(aiFix);
      }
    }

    return actions;
  }

  private getStaticFix(document: vscode.TextDocument, diagnostic: vscode.Diagnostic): vscode.CodeAction | null {
    const rule = diagnostic.code as string;

    switch (rule) {
      case 'img-alt': {
        const risk = getStaticFixRisk('img-alt');
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'alt=""',
          'Add empty alt attribute (decorative image)',
          risk,
        );
      }

      case 'button-label': {
        // Try to infer a meaningful label from child icon name (e.g. <Close /> → "Close")
        const inferredLabel = this.inferIconLabel(document, diagnostic);
        const risk = getStaticFixRisk('button-label', inferredLabel ?? undefined);
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          inferredLabel ? `aria-label="${inferredLabel}"` : 'aria-label=""',
          inferredLabel ? `Add aria-label="${inferredLabel}"` : 'Add aria-label attribute',
          risk,
        );
      }

      case 'form-label': {
        const risk = getStaticFixRisk('form-label');
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'aria-label=""',
          'Add aria-label attribute',
          risk,
        );
      }

      case 'click-events-have-key-events': {
        const risk = getStaticFixRisk('click-events-have-key-events');
        return this.createInsertAttributesFix(
          document,
          diagnostic,
          ['role="button"', 'tabIndex={0}', 'onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { /* handler */ } }}'],
          'Add keyboard support (role, tabIndex, onKeyDown)',
          risk,
        );
      }

      case 'aria-pattern': {
        const msg = diagnostic.message;
        if (msg.includes('aria-labelledby') || msg.includes('aria-label')) {
          const risk = getStaticFixRisk('aria-pattern', msg);
          return this.createInsertAttributeFix(
            document,
            diagnostic,
            'aria-label=""',
            'Add aria-label attribute',
            risk,
          );
        }
        if (msg.includes('aria-expanded')) {
          const risk = getStaticFixRisk('aria-pattern', msg);
          return this.createInsertAttributeFix(
            document,
            diagnostic,
            'aria-expanded={false}',
            'Add aria-expanded attribute',
            risk,
          );
        }
        if (msg.includes('aria-controls') || msg.includes('aria-selected')) {
          const risk = getStaticFixRisk('aria-pattern', msg);
          return this.createInsertAttributesFix(
            document,
            diagnostic,
            ['aria-controls=""', 'aria-selected={false}'],
            'Add aria-controls and aria-selected',
            risk,
          );
        }
        return null;
      }

      case 'heading-order': {
        const data = getDiagnosticData(document.uri, diagnostic);
        const msg = diagnostic.message;

        if (data?.type === 'skipped' && data.currentTag && data.previousLevel) {
          const suggestedLevel = parseInt(data.previousLevel, 10) + 1;
          if (suggestedLevel <= 6) {
            return this.createReplaceHeadingFix(document, diagnostic, data.currentTag, `h${suggestedLevel}`);
          }
        } else if (data?.type === 'multiple-h1') {
          return this.createReplaceHeadingFix(document, diagnostic, 'h1', 'h2');
        } else if (data?.type === 'first-heading' && data.currentTag) {
          return this.createReplaceHeadingFix(document, diagnostic, data.currentTag, 'h1');
        }

        // Regex fallback for diagnostics without structured data
        const currentTagMatch = msg.match(/<(h[1-6])>/);
        if (currentTagMatch && msg.includes('skipped')) {
          const prevMatch = msg.match(/follows `<h(\d)>/);
          if (prevMatch) {
            const suggestedLevel = parseInt(prevMatch[1], 10) + 1;
            if (suggestedLevel <= 6) {
              return this.createReplaceHeadingFix(document, diagnostic, currentTagMatch[1], `h${suggestedLevel}`);
            }
          }
        }
        if (msg.includes('Multiple') && msg.includes('<h1>')) {
          return this.createReplaceHeadingFix(document, diagnostic, 'h1', 'h2');
        }
        if (msg.includes('First heading') && currentTagMatch) {
          return this.createReplaceHeadingFix(document, diagnostic, currentTagMatch[1], 'h1');
        }
        return null;
      }

      case 'aria-role': {
        const data = getDiagnosticData(document.uri, diagnostic);
        const invalidRole = data?.invalidRole ?? diagnostic.message.match(/Invalid ARIA role "([^"]+)"/)?.[1];
        if (invalidRole) {
          const closest = findClosestRole(invalidRole);
          if (closest) {
            const risk = getStaticFixRisk('aria-role');
            return this.createReplaceRoleValueFix(document, diagnostic, invalidRole, closest, risk);
          }
        }
        return null;
      }

      case 'color-contrast': {
        const data = getDiagnosticData(document.uri, diagnostic);
        const fg = data?.foreground ?? diagnostic.message.match(/foreground: "([^"]+)"/)?.[1];
        const bg = data?.background ?? diagnostic.message.match(/background: "([^"]+)"/)?.[1];
        if (fg && bg) {
          const fixedFg = suggestAccessibleForeground(fg, bg);
          if (fixedFg) {
            const risk = getStaticFixRisk('color-contrast');
            return this.createReplaceColorFix(document, diagnostic, fg, fixedFg, risk);
          }
        }
        return null;
      }

      case 'nextjs-image-alt': {
        const risk = getStaticFixRisk('nextjs-image-alt');
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'alt=""',
          'Add alt attribute to Next.js Image',
          risk,
        );
      }

      case 'nextjs-head-lang': {
        const risk = getStaticFixRisk('nextjs-head-lang');
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'lang="en"',
          'Add lang attribute',
          risk,
        );
      }

      case 'nextjs-link-text': {
        const risk = getStaticFixRisk('nextjs-link-text');
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'aria-label=""',
          'Add aria-label to Next.js Link',
          risk,
        );
      }

      default:
        return null;
    }
  }

  private createInsertAttributeFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    attribute: string,
    title: string,
    risk?: StaticFixRisk,
  ): vscode.CodeAction {
    const confidenceLabel = risk ? ` [${risk.confidence}%]` : '';
    const fix = new vscode.CodeAction(
      `A11y: ${title}${confidenceLabel}`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];
    if (risk?.caveat) {
      fix.diagnostics = [diagnostic];
    }

    const line = document.lineAt(diagnostic.range.start.line);
    const lineText = line.text;
    const tagStart = diagnostic.range.start.character;
    const insertIndex = findOpeningTagClose(lineText, tagStart);

    const edit = new vscode.WorkspaceEdit();
    if (insertIndex !== -1) {
      const insertPosition = new vscode.Position(diagnostic.range.start.line, insertIndex);
      edit.insert(document.uri, insertPosition, ` ${attribute}`);
      fix.edit = edit;
    } else {
      // Multiline tag — scan forward to find the closing > or />
      const multiline = findOpeningTagCloseMultiline(document, diagnostic.range.start.line, tagStart);
      if (multiline) {
        const insertPosition = new vscode.Position(multiline.line, multiline.column);
        edit.insert(document.uri, insertPosition, ` ${attribute}`);
        fix.edit = edit;
      }
    }

    fix.isPreferred = true;
    return fix;
  }

  private createInsertAttributesFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    attributes: string[],
    title: string,
    risk?: StaticFixRisk,
  ): vscode.CodeAction {
    const confidenceLabel = risk ? ` [${risk.confidence}%]` : '';
    const fix = new vscode.CodeAction(
      `A11y: ${title}${confidenceLabel}`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const line = document.lineAt(diagnostic.range.start.line);
    const lineText = line.text;
    const tagStart = diagnostic.range.start.character;
    const insertIndex = findOpeningTagClose(lineText, tagStart);

    const edit = new vscode.WorkspaceEdit();
    if (insertIndex !== -1) {
      const insertPosition = new vscode.Position(diagnostic.range.start.line, insertIndex);
      edit.insert(document.uri, insertPosition, ` ${attributes.join(' ')}`);
      fix.edit = edit;
    } else {
      const multiline = findOpeningTagCloseMultiline(document, diagnostic.range.start.line, tagStart);
      if (multiline) {
        const insertPosition = new vscode.Position(multiline.line, multiline.column);
        edit.insert(document.uri, insertPosition, ` ${attributes.join(' ')}`);
        fix.edit = edit;
      }
    }

    return fix;
  }

  /**
   * Try to infer a label for an IconButton from its child icon element.
   * Scans lines after the opening tag for patterns like `<Close .../>`, `<EditIcon .../>`,
   * and converts the PascalCase name into a readable label ("Close", "Edit").
   */
  private inferIconLabel(document: vscode.TextDocument, diagnostic: vscode.Diagnostic): string | null {
    const startLine = diagnostic.range.start.line;
    const maxLine = Math.min(startLine + 10, document.lineCount - 1);

    for (let i = startLine; i <= maxLine; i++) {
      const text = document.lineAt(i).text;
      // Match self-closing JSX children like <Close />, <EditIcon />, <ArrowBack fontSize="small" />
      const iconMatch = text.match(/<([A-Z][a-zA-Z]*?)(?:Icon)?\s+[^>]*\/>/);
      if (iconMatch) {
        // Convert PascalCase to words: "ArrowBack" → "Arrow Back" → "Arrow back"
        const raw = iconMatch[1].replace(/([a-z])([A-Z])/g, '$1 $2');
        return raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
      }
      // Also match <Close /> with no extra props
      const simpleMatch = text.match(/<([A-Z][a-zA-Z]*?)(?:Icon)?\s*\/>/);
      if (simpleMatch) {
        const raw = simpleMatch[1].replace(/([a-z])([A-Z])/g, '$1 $2');
        return raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
      }
    }
    return null;
  }

  private createReplaceHeadingFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    currentTag: string,
    suggestedTag: string,
  ): vscode.CodeAction {
    const riskCtx = diagnostic.message.includes('Multiple') ? 'multiple-h1' : undefined;
    const risk = getStaticFixRisk('heading-order', riskCtx);
    const fix = new vscode.CodeAction(
      `A11y: Change <${currentTag}> to <${suggestedTag}> [${risk.confidence}%]`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const edit = new vscode.WorkspaceEdit();
    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;

    // Replace the opening tag
    const openIdx = lineText.indexOf(`<${currentTag}`);
    if (openIdx !== -1) {
      const openRange = new vscode.Range(lineNum, openIdx + 1, lineNum, openIdx + 1 + currentTag.length);
      edit.replace(document.uri, openRange, suggestedTag);
    }

    // Replace the closing tag on the same line (if present)
    const closeIdx = lineText.indexOf(`</${currentTag}>`);
    if (closeIdx !== -1) {
      const closeRange = new vscode.Range(lineNum, closeIdx + 2, lineNum, closeIdx + 2 + currentTag.length);
      edit.replace(document.uri, closeRange, suggestedTag);
    }

    fix.edit = edit;
    fix.isPreferred = true;
    return fix;
  }

  private createReplaceRoleValueFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    invalidRole: string,
    suggestedRole: string,
    risk?: StaticFixRisk,
  ): vscode.CodeAction {
    const confidenceLabel = risk ? ` [${risk.confidence}%]` : '';
    const fix = new vscode.CodeAction(
      `A11y: Replace role="${invalidRole}" with "${suggestedRole}"${confidenceLabel}`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const edit = new vscode.WorkspaceEdit();
    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;
    const idx = lineText.indexOf(`"${invalidRole}"`);
    if (idx !== -1) {
      const range = new vscode.Range(lineNum, idx + 1, lineNum, idx + 1 + invalidRole.length);
      edit.replace(document.uri, range, suggestedRole);
    }
    fix.edit = edit;
    fix.isPreferred = true;
    return fix;
  }

  private createReplaceColorFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    originalColor: string,
    fixedColor: string,
    risk?: StaticFixRisk,
  ): vscode.CodeAction {
    const confidenceLabel = risk ? ` [${risk.confidence}%]` : '';
    const fix = new vscode.CodeAction(
      `A11y: Adjust foreground color to "${fixedColor}" for contrast${confidenceLabel}`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const edit = new vscode.WorkspaceEdit();
    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;

    // Replace the color value in the style's color property
    const colorPattern = new RegExp(`(color:\\s*["'])${escapeRegExp(originalColor)}(["'])`, 'i');
    const match = lineText.match(colorPattern);
    if (match && match.index !== undefined) {
      const valueStart = match.index + match[1].length;
      const range = new vscode.Range(lineNum, valueStart, lineNum, valueStart + originalColor.length);
      edit.replace(document.uri, range, fixedColor);
    }
    fix.edit = edit;
    fix.isPreferred = true;
    return fix;
  }
}

/**
 * Command handler: generates an AI fix and shows a diff preview for user approval.
 */
export async function applyAiFixCommand(uri: vscode.Uri, diagnostic: vscode.Diagnostic): Promise<void> {
  const document = await vscode.workspace.openTextDocument(uri);
  const lineText = document.lineAt(diagnostic.range.start.line).text;

  // Get surrounding context (5 lines before and after)
  const startLine = Math.max(0, diagnostic.range.start.line - 5);
  const endLine = Math.min(document.lineCount - 1, diagnostic.range.start.line + 5);
  const contextLines: string[] = [];
  for (let i = startLine; i <= endLine; i++) {
    contextLines.push(document.lineAt(i).text);
  }
  const surroundingContext = contextLines.join('\n');

  const issue = {
    message: diagnostic.message,
    rule: diagnostic.code as string,
    severity: 'warning' as const,
    line: diagnostic.range.start.line,
    column: diagnostic.range.start.character,
    snippet: lineText,
  };

  await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: 'A11y Scanner: Generating AI fix...',
      cancellable: false,
    },
    async () => {
      const fix = await getAiFix(lineText, issue, surroundingContext);
      if (!fix) {
        return;
      }

      // Cross-validate with axe-core
      const validation = validateFix(
        diagnostic.code as string,
        lineText,
        fix.fixedCode,
      );
      const wcagTags = getWcagTags(diagnostic.code as string);
      const helpUrl = getHelpUrl(diagnostic.code as string);

      // Blend AI confidence with axe-core validation
      const blendedConfidence = Math.round((fix.confidence + validation.adjustedConfidence) / 2);

      const reasoningParts = [fix.reasoning];
      if (wcagTags.length > 0) {
        reasoningParts.push(`WCAG: ${wcagTags.join(', ')}`);
      }
      if (helpUrl) {
        reasoningParts.push(`Ref: ${helpUrl}`);
      }
      if (validation.notes.length > 0) {
        reasoningParts.push(`Validation: ${validation.notes.join('; ')}`);
      }

      // Build a FullFileFixResult so the DiffPreviewPanel can display it
      const diagLine = diagnostic.range.start.line; // 0-based
      const change: A11yChange = {
        id: 1,
        startLine: diagLine + 1, // 1-based
        endLine: diagLine + 1,
        original: lineText,
        replacement: fix.fixedCode,
        explanation: fix.explanation,
        rule: diagnostic.code as string,
        confidence: blendedConfidence,
        reasoning: reasoningParts.filter(Boolean).join(' | '),
      };

      const result: FullFileFixResult = {
        changes: [change],
        designSystemDetected: null,
      };

      DiffPreviewPanel.createOrShow(uri, result);
    },
  );
}

/* ────────────────────────────────────────────────────────────────
 * Per-file static bulk fix
 * ──────────────────────────────────────────────────────────────── */

/**
 * Command handler: previews all static fixes for the current file.
 * Shows a BulkFixPreviewPanel so the user can accept/reject individual changes.
 */
export async function bulkFixFileCommand(): Promise<void> {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showWarningMessage('A11y Scanner: No active file to fix.');
    return;
  }

  const document = editor.document;
  const uri = document.uri;
  const diagnostics = await scanFileToDiagnostics(document);

  if (diagnostics.length === 0) {
    vscode.window.showInformationMessage('A11y Scanner: No accessibility issues found in this file.');
    return;
  }

  const entry = buildChangesForFile(document, uri, diagnostics);

  if (!entry || entry.changes.length === 0) {
    vscode.window.showInformationMessage('A11y Scanner: No auto-fixable issues in this file.');
    return;
  }

  BulkFixPreviewPanel.createOrShow({ files: [entry] });
}

/**
 * Extracts the rule string from a diagnostic's code.
 */
function extractRuleCode(diagnostic: vscode.Diagnostic): string | undefined {
  const code = diagnostic.code;
  if (typeof code === 'string') { return code; }
  if (typeof code === 'number') { return String(code); }
  if (code && typeof code === 'object' && 'value' in code) {
    return String(code.value);
  }
  return undefined;
}

/**
 * Scan a document using the AST scanner and return VS Code Diagnostics.
 */
async function scanFileToDiagnostics(document: vscode.TextDocument): Promise<vscode.Diagnostic[]> {
  const config = await loadConfig();
  let issues = scanForA11yIssues(document.getText(), document.fileName);
  issues = applyConfig(config, issues);

  return issues.map(issue => {
    const startPos = new vscode.Position(issue.line, issue.column);
    const endPos = issue.endLine !== undefined && issue.endColumn !== undefined
      ? new vscode.Position(issue.endLine, issue.endColumn)
      : document.lineAt(issue.line).range.end;
    const range = new vscode.Range(startPos, endPos);
    const diagnostic = new vscode.Diagnostic(range, issue.message, toVscodeSeverity(issue.severity));
    diagnostic.source = 'A11y Scanner';
    diagnostic.code = issue.rule;
    return diagnostic;
  });
}

/**
 * Builds preview changes for a single file from its diagnostics.
 */
function buildChangesForFile(
  document: vscode.TextDocument,
  uri: vscode.Uri,
  diagnostics: vscode.Diagnostic[],
): BulkFixFileEntry | null {
  const filtered = diagnostics.filter(d => {
    const rule = extractRuleCode(d);
    if (!rule) { return false; }
    if (getStaticFixAttribute(rule, d) !== null) { return true; }
    const lineText = document.lineAt(d.range.start.line).text;
    return getStaticFixReplacement(rule, d, lineText) !== null;
  });

  if (filtered.length === 0) { return null; }

  const changes: A11yChange[] = [];
  let nextId = 1;

  for (const diagnostic of filtered) {
    const rule = extractRuleCode(diagnostic);
    if (!rule) { continue; }

    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;

    // Try attribute insertion first
    const attribute = getStaticFixAttribute(rule, diagnostic);
    if (attribute) {
      const tagStart = diagnostic.range.start.character;
      const insertIndex = findOpeningTagClose(lineText, tagStart);

      const riskContext = rule === 'aria-pattern' ? diagnostic.message : undefined;
      const risk = getStaticFixRisk(rule, riskContext);
      const wcagTags = getWcagTags(rule);
      const reasoningParts = [risk.reasoning];
      if (wcagTags.length > 0) { reasoningParts.push(`WCAG: ${wcagTags.join(', ')}`); }
      if (risk.caveat) { reasoningParts.push(`Caveat: ${risk.caveat}`); }
      const fullReasoning = reasoningParts.join(' | ');

      if (insertIndex !== -1) {
        changes.push({
          id: nextId++, startLine: lineNum + 1, endLine: lineNum + 1,
          original: lineText,
          replacement: lineText.substring(0, insertIndex) + ` ${attribute}` + lineText.substring(insertIndex),
          explanation: `Add \`${attribute}\` to fix ${rule}`,
          rule, confidence: risk.confidence, reasoning: fullReasoning,
        });
      } else {
        const multiline = findOpeningTagCloseMultiline(document, lineNum, tagStart);
        if (multiline) {
          const closingLineText = document.lineAt(multiline.line).text;
          const targetLine = multiline.line;
          const targetText = targetLine === lineNum ? lineText : closingLineText;
          changes.push({
            id: nextId++, startLine: targetLine + 1, endLine: targetLine + 1,
            original: targetText,
            replacement: targetText.substring(0, multiline.column) + ` ${attribute}` + targetText.substring(multiline.column),
            explanation: `Add \`${attribute}\` to fix ${rule}`,
            rule, confidence: risk.confidence, reasoning: fullReasoning,
          });
        }
      }
      continue;
    }

    // Try full line replacement (heading-order, aria-role, color-contrast)
    const lineReplacement = getStaticFixReplacement(rule, diagnostic, lineText);
    if (lineReplacement) {
      const repRiskCtx = rule === 'heading-order' && diagnostic.message.includes('Multiple') ? 'multiple-h1' : undefined;
      const repRisk = getStaticFixRisk(rule, repRiskCtx);
      const repWcag = getWcagTags(rule);
      const repReasoningParts = [repRisk.reasoning];
      if (repWcag.length > 0) { repReasoningParts.push(`WCAG: ${repWcag.join(', ')}`); }
      if (repRisk.caveat) { repReasoningParts.push(`Caveat: ${repRisk.caveat}`); }
      changes.push({
        id: nextId++, startLine: lineNum + 1, endLine: lineNum + 1,
        original: lineText, replacement: lineReplacement.replacement,
        explanation: lineReplacement.explanation, rule,
        confidence: repRisk.confidence, reasoning: repReasoningParts.join(' | '),
      });
    }
  }

  if (changes.length === 0) { return null; }
  return { uri, relativePath: vscode.workspace.asRelativePath(uri), changes };
}

/**
 * Returns the attribute string to insert for a given rule, or null if no static fix exists.
 */
function getStaticFixAttribute(ruleId: string, diagnostic: vscode.Diagnostic): string | null {
  switch (ruleId) {
    case 'img-alt': return 'alt=""';
    case 'button-label': return 'aria-label=""';
    case 'form-label': return 'aria-label=""';
    case 'click-events-have-key-events':
      return 'role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { /* handler */ } }}';
    case 'nextjs-image-alt': return 'alt=""';
    case 'nextjs-head-lang': return 'lang="en"';
    case 'nextjs-link-text': return 'aria-label=""';
    case 'autocomplete-valid': return 'autoComplete="name"';
    case 'no-mouse-only-hover': return 'onFocus={() => {}}';
    case 'aria-pattern': {
      const msg = diagnostic.message;
      if (msg.includes('aria-labelledby') || msg.includes('aria-label')) { return 'aria-label=""'; }
      if (msg.includes('aria-expanded')) { return 'aria-expanded={false}'; }
      if (msg.includes('aria-controls') || msg.includes('aria-selected')) { return 'aria-controls="" aria-selected={false}'; }
      return null;
    }
    default: return null;
  }
}

/**
 * Returns a full line replacement for rules that need more than attribute insertion.
 */
function getStaticFixReplacement(
  ruleId: string,
  diagnostic: vscode.Diagnostic,
  lineText: string,
): { replacement: string; explanation: string } | null {
  switch (ruleId) {
    case 'heading-order': {
      const msg = diagnostic.message;
      const currentTagMatch = msg.match(/<(h[1-6])>/);
      let currentTag: string | null = null;
      let targetTag: string | null = null;

      if (currentTagMatch && msg.includes('skipped')) {
        const prevMatch = msg.match(/follows `<h(\d)>/);
        if (prevMatch) {
          const suggested = parseInt(prevMatch[1], 10) + 1;
          if (suggested <= 6) { currentTag = currentTagMatch[1]; targetTag = `h${suggested}`; }
        }
      } else if (msg.includes('Multiple') && msg.includes('<h1>')) {
        currentTag = 'h1'; targetTag = 'h2';
      } else if (msg.includes('First heading') && currentTagMatch) {
        currentTag = currentTagMatch[1]; targetTag = 'h1';
      }

      if (currentTag && targetTag) {
        let replacement = lineText;
        replacement = replacement.replace(
          new RegExp(`<${escapeRegExp(currentTag)}(\\s|>|/>)`), `<${targetTag}$1`,
        );
        replacement = replacement.replace(
          new RegExp(`</${escapeRegExp(currentTag)}>`), `</${targetTag}>`,
        );
        if (replacement !== lineText) {
          return { replacement, explanation: `Change <${currentTag}> to <${targetTag}>` };
        }
      }
      return null;
    }
    case 'aria-role': {
      const roleMatch = diagnostic.message.match(/Invalid ARIA role "([^"]+)"/);
      if (roleMatch) {
        const invalidRole = roleMatch[1];
        const closest = findClosestRole(invalidRole);
        if (closest) {
          const replacement = lineText.replace(`"${invalidRole}"`, `"${closest}"`);
          if (replacement !== lineText) {
            return { replacement, explanation: `Replace invalid role "${invalidRole}" with "${closest}"` };
          }
        }
      }
      return null;
    }
    case 'color-contrast': {
      const fgMatch = diagnostic.message.match(/foreground: "([^"]+)"/);
      const bgMatch = diagnostic.message.match(/background: "([^"]+)"/);
      if (fgMatch && bgMatch) {
        const fixedFg = suggestAccessibleForeground(fgMatch[1], bgMatch[1]);
        if (fixedFg) {
          const colorPattern = new RegExp(
            `(color:\\s*["'])${escapeRegExp(fgMatch[1])}(["'])`, 'i',
          );
          const replacement = lineText.replace(colorPattern, `$1${fixedFg}$2`);
          if (replacement !== lineText) {
            return { replacement, explanation: `Adjust foreground color to "${fixedFg}" for sufficient contrast` };
          }
        }
      }
      return null;
    }
    default: return null;
  }
}

