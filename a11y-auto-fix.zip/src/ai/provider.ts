import * as vscode from 'vscode';
import * as crypto from 'crypto';
import type { A11yIssue, AiFixResponse } from '../types';

const SYSTEM_PROMPT = `You are an accessibility expert specializing in React and WCAG 2.1 compliance.
Given a code snippet and an accessibility issue, provide a minimal, targeted fix.
Return a JSON object with these fields:
- "fixedCode": the corrected code snippet (only the relevant element, not the whole file)
- "explanation": a brief one-sentence explanation of the fix
- "confidence": a number from 0 to 100 indicating how confident you are that this fix correctly resolves the issue without side effects
- "reasoning": a 1-3 sentence explanation of WHY this fix is correct, referencing the relevant WCAG criterion and what accessibility barrier it removes

Rules:
- Only fix the specific accessibility issue mentioned
- Preserve existing functionality and styling
- Follow WCAG 2.1 Level AA guidelines
- Use semantic HTML where possible
- Do not add unnecessary attributes
- IMPORTANT: The code is JSX/React. Always use JSX attribute names: className (NOT class), htmlFor (NOT for), tabIndex (NOT tabindex), onClick/onKeyDown (NOT onclick/onkeydown). Never use HTML attribute names in JSX.`;

let _secrets: vscode.SecretStorage | undefined;

/**
 * Initialize the AI provider with the extension's SecretStorage.
 * Must be called once from activate().
 */
export function initAiProvider(secrets: vscode.SecretStorage): void {
  _secrets = secrets;
}

/**
 * Retrieve the stored API key from SecretStorage.
 */
export async function getStoredApiKey(): Promise<string | undefined> {
  if (!_secrets) { return undefined; }
  return _secrets.get('a11y.aiApiKey');
}

/**
 * Store the AI API key securely.
 */
export async function setAiApiKey(): Promise<void> {
  if (!_secrets) {
    vscode.window.showErrorMessage('A11y Scanner: Secret storage not initialized.');
    return;
  }
  const key = await vscode.window.showInputBox({
    prompt: 'Enter your AI provider API key',
    password: true,
    placeHolder: 'sk-...',
    ignoreFocusOut: true,
  });
  if (key !== undefined && key.trim().length > 0) {
    await _secrets.store('a11y.aiApiKey', key.trim());
    vscode.window.showInformationMessage('A11y Scanner: API key stored securely.');
  } else if (key !== undefined) {
    vscode.window.showWarningMessage('A11y Scanner: API key cannot be empty.');
  }
}

/* ── AI Fix Cache ────────────────────────────────────────────────────────── */

interface CachedFix {
  response: AiFixResponse;
  timestamp: number;
}

const AI_FIX_CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes
const AI_FIX_CACHE_MAX = 100;
const aiFixCache = new Map<string, CachedFix>();

function cacheKey(code: string, rule: string, message: string): string {
  const input = `${rule}::${message}::${code}`;
  return crypto.createHash('sha256').update(input).digest('hex');
}

function getCachedFix(code: string, rule: string, message: string): AiFixResponse | null {
  const key = cacheKey(code, rule, message);
  const cached = aiFixCache.get(key);
  if (!cached) { return null; }
  if (Date.now() - cached.timestamp > AI_FIX_CACHE_TTL_MS) {
    aiFixCache.delete(key);
    return null;
  }
  return cached.response;
}

function setCachedFix(code: string, rule: string, message: string, response: AiFixResponse): void {
  const key = cacheKey(code, rule, message);
  // Evict oldest if full
  if (aiFixCache.size >= AI_FIX_CACHE_MAX) {
    const firstKey = aiFixCache.keys().next().value;
    if (firstKey) { aiFixCache.delete(firstKey); }
  }
  aiFixCache.set(key, { response, timestamp: Date.now() });
}

/** Clear the AI fix cache (e.g. when provider/model settings change). */
export function clearAiFixCache(): void {
  aiFixCache.clear();
}

/**
 * Get an AI-powered fix suggestion for an accessibility issue.
 */
export async function getAiFix(code: string, issue: A11yIssue, surroundingContext: string): Promise<AiFixResponse | null> {
  const config = vscode.workspace.getConfiguration('a11y');
  const provider = config.get<string>('aiProvider', 'none');

  if (provider === 'none') {
    return null;
  }

  // Check cache first
  const cached = getCachedFix(code, issue.rule, issue.message);
  if (cached) {
    return cached;
  }

  // Retrieve API key from SecretStorage
  let apiKey: string | undefined;
  if (_secrets) {
    apiKey = await _secrets.get('a11y.aiApiKey');
  }
  const model = config.get<string>('aiModel', 'gpt-4');

  if (!apiKey) {
    const legacyKey = config.get<string>('aiApiKey', '');
    if (legacyKey) {
      vscode.window.showWarningMessage(
        'A11y Scanner: API key found in plaintext settings. Run "A11y: Set AI API Key" to store it securely, then remove a11y.aiApiKey from settings.',
      );
    } else {
      vscode.window.showWarningMessage('A11y Scanner: AI API key not configured. Run "A11y: Set AI API Key" to set it up.');
    }
    return null;
  }

  const userMessage = `Accessibility Issue: ${issue.message}
Rule: ${issue.rule}
Severity: ${issue.severity}

Code snippet with the issue:
\`\`\`tsx
${code}
\`\`\`

Surrounding context:
\`\`\`tsx
${surroundingContext}
\`\`\`

Provide a fix as JSON with "fixedCode" and "explanation" fields.`;

  try {
    let response: string;

    if (provider === 'azure-openai') {
      response = await callAzureOpenAI(apiKey, model, userMessage, config);
    } else {
      response = await callOpenAI(apiKey, model, userMessage);
    }

    const parsed = JSON.parse(response);
    const result: AiFixResponse = {
      fixedCode: parsed.fixedCode,
      explanation: parsed.explanation,
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : 70,
      reasoning: typeof parsed.reasoning === 'string' ? parsed.reasoning : '',
    };
    setCachedFix(code, issue.rule, issue.message, result);
    return result;
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    vscode.window.showErrorMessage(`A11y Scanner: AI fix failed - ${message}`);
    return null;
  }
}

const AI_TIMEOUT_MS = 60_000;

async function callOpenAI(apiKey: string, model: string, userMessage: string): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: userMessage },
        ],
        temperature: 0.2,
        response_format: { type: 'json_object' },
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as any;
    if (data?.error) {
      throw new Error(`OpenAI API error: HTTP ${response.status}`);
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== 'string') {
      throw new Error('Unexpected AI response format: no content returned');
    }
    return content;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function callAzureOpenAI(apiKey: string, deployment: string, userMessage: string, config: vscode.WorkspaceConfiguration): Promise<string> {
  const endpoint = config.get<string>('aiEndpoint', '');
  if (!endpoint) {
    throw new Error('Azure OpenAI endpoint not configured');
  }
  if (!endpoint.startsWith('https://')) {
    throw new Error('Azure OpenAI endpoint must use HTTPS');
  }

  const url = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=2024-02-01`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': apiKey,
      },
      body: JSON.stringify({
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: userMessage },
        ],
        temperature: 0.2,
        response_format: { type: 'json_object' },
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`Azure OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as any;
    if (data?.error) {
      throw new Error(`Azure OpenAI API error: HTTP ${response.status}`);
    }
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== 'string') {
      throw new Error('Unexpected AI response format: no content returned');
    }
    return content;
  } finally {
    clearTimeout(timeoutId);
  }
}
