import * as vscode from 'vscode';
import { initDiagnostics, updateDiagnostics, scanWorkspace, clearDiagnosticData } from './diagnostics';
import { A11yCodeActionProvider, applyAiFixCommand, bulkFixFileCommand } from './codeActions';
import { A11yReportPanel } from './webview/reportPanel';
import { ScreenReaderPanel } from './webview/screenReaderPanel';
import { createStatusBarItem, updateStatusBarScore } from './statusBar';
import { generateA11yTests } from './testGenerator';
import { compareWithLastCommit } from './gitRegression';
import { reviewPullRequest } from './prReview';
import { exportSarif, exportJson } from './exportReport';
import { initAiProvider, setAiApiKey, clearAiFixCache } from './ai/provider';
import { getFullFileFix } from './ai/fullFileFix';
import { scanForA11yIssues } from './scanner/astScanner';
import { DiffPreviewPanel } from './webview/diffPreviewPanel';
import { BulkFixPreviewPanel } from './webview/bulkFixPreviewPanel';
import { invalidateConfigCache } from './config';

export function activate(context: vscode.ExtensionContext): void {
  console.log('A11y Scanner extension activated');

  initDiagnostics(context);
  initAiProvider(context.secrets);

  const config = vscode.workspace.getConfiguration('a11y');

  if (config.get<boolean>('scanOnOpen', true)) {
    context.subscriptions.push(
      vscode.window.onDidChangeActiveTextEditor(editor => {
        if (editor) {
          updateDiagnostics(editor.document);
        }
      }),
    );
  }

  if (config.get<boolean>('scanOnSave', true)) {
    context.subscriptions.push(
      vscode.workspace.onDidSaveTextDocument(document => {
        updateDiagnostics(document);
      }),
    );
  }

  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(document => {
      updateDiagnostics(document);
    }),
  );

  const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument(event => {
      const key = event.document.uri.toString();
      const existing = debounceTimers.get(key);
      if (existing) { clearTimeout(existing); }
      debounceTimers.set(key, setTimeout(() => {
        debounceTimers.delete(key);
        updateDiagnostics(event.document);
      }, 500));
    }),
  );

  // Clean up debounce timers when documents close
  context.subscriptions.push(
    vscode.workspace.onDidCloseTextDocument(document => {
      const key = document.uri.toString();
      const timer = debounceTimers.get(key);
      if (timer) {
        clearTimeout(timer);
        debounceTimers.delete(key);
      }
    }),
  );

  if (vscode.window.activeTextEditor) {
    updateDiagnostics(vscode.window.activeTextEditor.document);
  }

  // Clean up diagnostic data when documents are closed
  context.subscriptions.push(
    vscode.workspace.onDidCloseTextDocument(document => {
      clearDiagnosticData(document.uri);
    }),
  );

  const configWatcher = vscode.workspace.createFileSystemWatcher('**/.a11yrc.json');
  configWatcher.onDidChange(() => invalidateConfigCache());
  configWatcher.onDidCreate(() => invalidateConfigCache());
  configWatcher.onDidDelete(() => invalidateConfigCache());
  context.subscriptions.push(configWatcher);

  // Clear AI fix cache when AI-related settings change
  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration('a11y.aiProvider') ||
          e.affectsConfiguration('a11y.aiModel') ||
          e.affectsConfiguration('a11y.aiEndpoint')) {
        clearAiFixCache();
      }
    }),
  );

  createStatusBarItem(context);

  context.subscriptions.push(
    vscode.languages.onDidChangeDiagnostics(() => updateStatusBarScore()),
  );
  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor(() => updateStatusBarScore()),
  );

  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      [
        { language: 'typescriptreact' },
        { language: 'javascriptreact' },
      ],
      new A11yCodeActionProvider(),
      {
        providedCodeActionKinds: A11yCodeActionProvider.providedCodeActionKinds,
      },
    ),
  );

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.scanWorkspace', async () => {
      try {
        const totalIssues = await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: 'A11y Scanner: Scanning workspace…',
            cancellable: true,
          },
          async (progress, token) => {
            return await scanWorkspace(progress, token);
          },
        );
        vscode.window.showInformationMessage(
          `A11y Scanner: Found ${totalIssues} accessibility issue(s) across the workspace.`,
        );
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Unknown error';
        vscode.window.showErrorMessage(`A11y Scanner: Workspace scan failed \u2014 ${msg}`);
      }
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.showReport', async () => {
      const fileUri = vscode.window.activeTextEditor?.document.uri;
      const choice = await vscode.window.showQuickPick(
        [
          { label: '$(file) Current File', description: 'Show issues for the active file', value: 'file' },
          { label: '$(folder) Entire Workspace', description: 'Show issues across all files', value: 'workspace' },
        ],
        { placeHolder: 'Show accessibility report for…' },
      );
      if (!choice) { return; }
      if (choice.value === 'file' && fileUri) {
        await A11yReportPanel.createOrShow(context, fileUri);
      } else {
        await A11yReportPanel.createOrShow(context);
      }
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.applyAiFix', async (uri: vscode.Uri, diagnostic: vscode.Diagnostic) => {
      await applyAiFixCommand(uri, diagnostic);
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.bulkFixFile', async () => {
      await bulkFixFileCommand();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.screenReaderPreview', () => {
      ScreenReaderPanel.createOrShow();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.setApiKey', async () => {
      await setAiApiKey();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.generateTests', async () => {
      await generateA11yTests();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.fixFile', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showWarningMessage('A11y Scanner: No active file to fix.');
        return;
      }
      const document = editor.document;

      try {
        const result = await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: 'A11y Scanner: Generating AI fixes for entire file…',
            cancellable: false,
          },
          () => getFullFileFix(document),
        );

        if (result && result.changes.length > 0) {
          DiffPreviewPanel.createOrShow(document.uri, result);
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Unknown error';
        vscode.window.showErrorMessage(`A11y Scanner: ${msg}`);
      }
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.compareWithLastCommit', async () => {
      await compareWithLastCommit();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.reviewPR', async () => {
      await reviewPullRequest(context);
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.exportSarif', async () => {
      await exportSarif();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.exportJson', async () => {
      await exportJson();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.bulkAiFix', async () => {
      const fileUris = await vscode.workspace.findFiles('**/*.{tsx,jsx}', '**/node_modules/**');
      if (fileUris.length === 0) {
        vscode.window.showInformationMessage('A11y Scanner: No TSX/JSX files found in workspace.');
        return;
      }

      const entries: import('./webview/bulkFixPreviewPanel').BulkFixFileEntry[] = [];
      const concurrency = vscode.workspace.getConfiguration('a11y').get<number>('aiBatchConcurrency', 10);
      let failedFiles = 0;
      let totalIssuesFound = 0;

      await vscode.window.withProgress(
        {
          location: vscode.ProgressLocation.Notification,
          title: 'A11y Scanner: Bulk AI Fix',
          cancellable: true,
        },
        async (progress, token) => {
          // Phase 1: Fast static scan to filter files with issues
          progress.report({ message: 'Scanning files for issues…' });
          const filesWithIssues: vscode.Uri[] = [];
          for (const fileUri of fileUris) {
            if (token.isCancellationRequested) { return; }
            try {
              const doc = await vscode.workspace.openTextDocument(fileUri);
              const issues = scanForA11yIssues(doc.getText(), doc.fileName);
              if (issues.length > 0) {
                filesWithIssues.push(fileUri);
                totalIssuesFound += issues.length;
              }
            } catch { /* skip unreadable files */ }
          }

          if (filesWithIssues.length === 0) {
            return; // no issues found — handled after withProgress
          }

          // Phase 2: Send files with issues to AI in parallel batches
          const total = filesWithIssues.length;
          let completed = 0;
          progress.report({
            message: `${total} file(s) with ${totalIssuesFound} issues — generating AI fixes…`,
          });

          for (let batchStart = 0; batchStart < total; batchStart += concurrency) {
            if (token.isCancellationRequested) { break; }

            const batch = filesWithIssues.slice(batchStart, batchStart + concurrency);
            const batchResults = await Promise.allSettled(
              batch.map(async (fileUri) => {
                const document = await vscode.workspace.openTextDocument(fileUri);
                const result = await getFullFileFix(document, { silent: true });
                return { fileUri, result };
              }),
            );

            for (const settled of batchResults) {
              completed++;
              if (settled.status === 'fulfilled') {
                const { fileUri, result } = settled.value;
                if (result && result.changes.length > 0) {
                  entries.push({
                    uri: fileUri,
                    relativePath: vscode.workspace.asRelativePath(fileUri),
                    changes: result.changes,
                  });
                } else if (!result) {
                  failedFiles++;
                }
              } else {
                failedFiles++;
              }
            }

            progress.report({
              increment: (batch.length / total) * 100,
              message: `AI fixes: ${completed}/${total} files processed (${entries.length} with fixes)`,
            });
          }
        },
      );

      if (entries.length === 0) {
        const detail = failedFiles > 0
          ? ` (${failedFiles} file(s) failed AI analysis — check API key, endpoint, and rate limits)`
          : '';
        vscode.window.showInformationMessage(`A11y Scanner: No AI-fixable issues found across the workspace.${detail}`);
        return;
      }

      const totalChanges = entries.reduce((sum, e) => sum + e.changes.length, 0);
      BulkFixPreviewPanel.createOrShow({ files: entries });
      let summary = `A11y Scanner: AI generated ${totalChanges} fix(es) across ${entries.length} file(s).`;
      if (failedFiles > 0) {
        summary += ` ${failedFiles} file(s) failed AI analysis.`;
      }
      vscode.window.showInformationMessage(summary);
    }),
  );
}

export function deactivate(): void {
  console.log('A11y Scanner extension deactivated');
}
