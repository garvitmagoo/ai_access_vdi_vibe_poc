import * as vscode from 'vscode';
import * as path from 'path';
import * as cp from 'child_process';
import { scanForA11yIssues } from './scanner/astScanner';
import type { A11yIssue, PrFileResult, PrReviewResult } from './types';
import { PrReviewPanel } from './webview/prReviewPanel';

/* ── Public command ─────────────────────────────────────────────────────── */

export async function reviewPullRequest(context: vscode.ExtensionContext): Promise<void> {
  try {
    await reviewPullRequestUnsafe(context);
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Unknown error';
    vscode.window.showErrorMessage(`A11y Scanner: PR review failed — ${msg}`);
  }
}

/* ── Implementation ─────────────────────────────────────────────────────── */

async function reviewPullRequestUnsafe(context: vscode.ExtensionContext): Promise<void> {
  const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
  if (!workspaceFolder) {
    vscode.window.showWarningMessage('A11y Scanner: No workspace folder open.');
    return;
  }

  const cwd = workspaceFolder.uri.fsPath;

  if (!(await isGitRepo(cwd))) {
    vscode.window.showWarningMessage('A11y Scanner: This workspace is not a git repository.');
    return;
  }

  const currentBranch = await getCurrentBranch(cwd);
  if (!currentBranch) {
    vscode.window.showWarningMessage('A11y Scanner: Unable to determine current branch.');
    return;
  }

  // Let the user pick the base branch to compare against
  const baseBranch = await pickBaseBranch(cwd, currentBranch);
  if (!baseBranch) {
    return; // user cancelled
  }

  const result = await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: 'A11y Scanner: Reviewing PR for accessibility…',
      cancellable: true,
    },
    async (progress, token) => {
      return await runPrReview(cwd, baseBranch, currentBranch, progress, token);
    },
  );

  if (!result) {
    return;
  }

  PrReviewPanel.createOrShow(context, result);
}

/* ── Git helpers ────────────────────────────────────────────────────────── */

function isGitRepo(cwd: string): Promise<boolean> {
  return new Promise(resolve => {
    cp.exec('git rev-parse --is-inside-work-tree', { cwd }, err => {
      resolve(!err);
    });
  });
}

function getCurrentBranch(cwd: string): Promise<string | null> {
  return new Promise(resolve => {
    cp.execFile('git', ['rev-parse', '--abbrev-ref', 'HEAD'], {
      cwd,
      encoding: 'utf-8',
      timeout: 10_000,
    }, (err, stdout) => {
      resolve(err ? null : stdout.trim());
    });
  });
}

async function listBranches(cwd: string): Promise<string[]> {
  return new Promise(resolve => {
    cp.execFile('git', ['branch', '-a', '--format=%(refname:short)'], {
      cwd,
      encoding: 'utf-8',
      timeout: 10_000,
    }, (err, stdout) => {
      if (err) { resolve([]); return; }
      const branches = stdout
        .split('\n')
        .map(b => b.trim())
        .filter(Boolean);
      resolve(branches);
    });
  });
}

async function pickBaseBranch(cwd: string, currentBranch: string): Promise<string | undefined> {
  const branches = await listBranches(cwd);

  // Prioritize common base branches at the top
  const prioritized = ['main', 'master', 'develop', 'dev'];
  const sorted = [
    ...prioritized.filter(b => branches.includes(b) && b !== currentBranch),
    ...branches.filter(b => !prioritized.includes(b) && b !== currentBranch),
  ];

  const items: vscode.QuickPickItem[] = sorted.map(b => ({
    label: b,
    description: prioritized.includes(b) ? 'common base branch' : undefined,
  }));

  const pick = await vscode.window.showQuickPick(items, {
    placeHolder: `Select base branch to compare "${currentBranch}" against`,
    title: 'A11y PR Review: Choose Base Branch',
  });

  return pick?.label;
}

/**
 * Get the list of files changed between baseBranch and HEAD.
 * Returns objects with { status, file, oldFile? }.
 */
function getChangedFiles(cwd: string, baseBranch: string): Promise<{ status: string; file: string; oldFile?: string }[]> {
  return new Promise(resolve => {
    // Use merge-base to find the common ancestor
    cp.execFile('git', ['merge-base', baseBranch, 'HEAD'], {
      cwd,
      encoding: 'utf-8',
      timeout: 10_000,
    }, (err, mergeBase) => {
      if (err) { resolve([]); return; }

      cp.execFile('git', ['diff', '--name-status', '--diff-filter=AMRCT', mergeBase.trim(), 'HEAD'], {
        cwd,
        encoding: 'utf-8',
        maxBuffer: 1024 * 1024,
        timeout: 30_000,
      }, (err2, stdout) => {
        if (err2) { resolve([]); return; }

        const results: { status: string; file: string; oldFile?: string }[] = [];
        for (const line of stdout.split('\n')) {
          if (!line.trim()) { continue; }
          const parts = line.split('\t');
          const statusChar = parts[0]?.[0];
          if (!statusChar) { continue; }

          if (statusChar === 'R' && parts.length >= 3) {
            results.push({ status: 'R', file: parts[2], oldFile: parts[1] });
          } else if (parts[1]) {
            results.push({ status: statusChar, file: parts[1] });
          }
        }
        resolve(results);
      });
    });
  });
}

/**
 * Get file contents at a specific ref, or null if it didn't exist.
 */
function getFileAtRef(cwd: string, ref: string, relativePath: string): Promise<string | null> {
  const normalized = path.normalize(relativePath).replace(/\\/g, '/');
  if (normalized.startsWith('..') || path.isAbsolute(normalized)) {
    return Promise.resolve(null);
  }
  return new Promise(resolve => {
    cp.execFile('git', ['show', `${ref}:${normalized}`], {
      cwd,
      encoding: 'utf-8',
      maxBuffer: 1024 * 1024,
      timeout: 10_000,
    }, (err, stdout) => {
      resolve(err ? null : stdout);
    });
  });
}

/* ── Core review logic ──────────────────────────────────────────────────── */

async function runPrReview(
  cwd: string,
  baseBranch: string,
  currentBranch: string,
  progress: vscode.Progress<{ message?: string; increment?: number }>,
  token?: vscode.CancellationToken,
): Promise<PrReviewResult | null> {
  // Find merge-base for scanning base versions
  const mergeBase = await getMergeBase(cwd, baseBranch);
  if (!mergeBase) {
    vscode.window.showWarningMessage('A11y Scanner: Unable to find common ancestor between branches.');
    return null;
  }

  progress.report({ message: 'Finding changed files…' });
  const changedFiles = await getChangedFiles(cwd, baseBranch);

  // Filter to only TSX/JSX/TS/JS files
  const supportedExtensions = ['.tsx', '.jsx', '.ts', '.js'];
  const relevantFiles = changedFiles.filter(f =>
    supportedExtensions.includes(path.extname(f.file).toLowerCase()),
  );

  if (relevantFiles.length === 0) {
    vscode.window.showInformationMessage('A11y Scanner: No relevant JSX/TSX files changed in this PR.');
    return null;
  }

  const files: PrFileResult[] = [];
  let totalNew = 0;
  let totalFixed = 0;
  let totalCurrent = 0;
  let totalPrevious = 0;

  for (let i = 0; i < relevantFiles.length; i++) {
    if (token?.isCancellationRequested) { break; }

    const changed = relevantFiles[i];
    progress.report({
      message: `Scanning ${changed.file} (${i + 1}/${relevantFiles.length})`,
      increment: (1 / relevantFiles.length) * 100,
    });

    const filePath = path.join(cwd, changed.file);
    const status: PrFileResult['status'] =
      changed.status === 'A' ? 'added' :
      changed.status === 'R' ? 'renamed' : 'modified';

    // Get current file content from the working tree
    let currentSource: string;
    try {
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(filePath));
      currentSource = doc.getText();
    } catch {
      // File may have been deleted or isn't readable
      continue;
    }

    // Scan current version
    const currentIssues = scanForA11yIssues(currentSource, filePath);

    // Get base version
    const baseFile = changed.oldFile ?? changed.file;
    const baseSource = status === 'added' ? null : await getFileAtRef(cwd, mergeBase, baseFile);
    const previousIssues = baseSource ? scanForA11yIssues(baseSource, filePath) : [];

    // Diff issues by stable key (rule + message)
    const prevKeys = new Set(previousIssues.map(issueKey));
    const currKeys = new Set(currentIssues.map(issueKey));

    const newIssues = currentIssues.filter(i => !prevKeys.has(issueKey(i)));
    const fixedIssues = previousIssues.filter(i => !currKeys.has(issueKey(i)));

    totalNew += newIssues.length;
    totalFixed += fixedIssues.length;
    totalCurrent += currentIssues.length;
    totalPrevious += previousIssues.length;

    files.push({
      file: changed.file,
      status,
      newIssues,
      fixedIssues,
      currentIssues,
      previousIssues,
    });
  }

  // PR passes if no new issues were introduced
  const pass = totalNew === 0;

  return {
    baseBranch,
    currentBranch,
    files,
    totalNew,
    totalFixed,
    totalCurrent,
    totalPrevious,
    pass,
  };
}

function getMergeBase(cwd: string, baseBranch: string): Promise<string | null> {
  return new Promise(resolve => {
    cp.execFile('git', ['merge-base', baseBranch, 'HEAD'], {
      cwd,
      encoding: 'utf-8',
      timeout: 10_000,
    }, (err, stdout) => {
      resolve(err ? null : stdout.trim());
    });
  });
}

function issueKey(issue: A11yIssue): string {
  return `${issue.rule}::${issue.message}`;
}
