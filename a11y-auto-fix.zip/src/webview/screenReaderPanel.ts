import * as vscode from 'vscode';
import { simulateScreenReader, ScreenReaderAnnouncement } from '../scanner/screenReaderSimulator';
import { escapeHtml as esc, getNonce } from './utils';

/**
 * Webview panel that shows what a screen reader would announce
 * for elements in the active file.
 */
export class ScreenReaderPanel {
  public static currentPanel: ScreenReaderPanel | undefined;
  private readonly panel: vscode.WebviewPanel;
  private disposables: vscode.Disposable[] = [];
  private refreshTimer: ReturnType<typeof setTimeout> | undefined;
  /** Last known text document — used as fallback when the webview steals focus. */
  private lastDocument: vscode.TextDocument | undefined;

  private constructor(panel: vscode.WebviewPanel, initialDocument?: vscode.TextDocument) {
    this.panel = panel;
    this.lastDocument = initialDocument;
    this.panel.onDidDispose(() => this.dispose(), null, this.disposables);

    // Refresh when the active editor changes
    this.disposables.push(
      vscode.window.onDidChangeActiveTextEditor(editor => {
        if (editor) {
          this.lastDocument = editor.document;
        }
        this.refresh();
      }),
    );

    // Debounced refresh when the active document is edited
    this.disposables.push(
      vscode.workspace.onDidChangeTextDocument(e => {
        const relevantDoc = vscode.window.activeTextEditor?.document ?? this.lastDocument;
        if (relevantDoc === e.document) {
          if (this.refreshTimer) { clearTimeout(this.refreshTimer); }
          this.refreshTimer = setTimeout(() => {
            this.refreshTimer = undefined;
            this.refresh();
          }, 500);
        }
      }),
    );
  }

  public static createOrShow(): void {
    const column = vscode.ViewColumn.Beside;
    // Capture the active editor BEFORE creating/revealing the panel,
    // because the webview steals focus and makes activeTextEditor undefined.
    const currentEditor = vscode.window.activeTextEditor;

    if (ScreenReaderPanel.currentPanel) {
      if (currentEditor) {
        ScreenReaderPanel.currentPanel.lastDocument = currentEditor.document;
      }
      ScreenReaderPanel.currentPanel.panel.reveal(column);
      ScreenReaderPanel.currentPanel.refresh();
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      'a11yScreenReader',
      'Screen Reader Preview',
      column,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
      },
    );

    ScreenReaderPanel.currentPanel = new ScreenReaderPanel(panel, currentEditor?.document);
    ScreenReaderPanel.currentPanel.refresh();
  }

  private refresh(): void {
    const editor = vscode.window.activeTextEditor;
    const doc = editor?.document ?? this.lastDocument;

    if (!doc) {
      this.panel.webview.html = buildEmptyHtml(this.panel.webview, 'No active file');
      return;
    }

    const supported = ['typescriptreact', 'javascriptreact', 'typescript', 'javascript'];
    if (!supported.includes(doc.languageId)) {
      this.panel.webview.html = buildEmptyHtml(this.panel.webview, 'Not a JSX/TSX file');
      return;
    }

    const announcements = simulateScreenReader(doc.getText(), doc.fileName);
    this.panel.webview.html = buildHtml(announcements, vscode.workspace.asRelativePath(doc.uri), this.panel.webview);
  }

  private dispose(): void {
    ScreenReaderPanel.currentPanel = undefined;
    if (this.refreshTimer) { clearTimeout(this.refreshTimer); }
    this.panel.dispose();
    this.disposables.forEach(d => d.dispose());
  }
}

/* ── HTML builders ──────────────────────────────────────── */

function buildEmptyHtml(_webview: vscode.Webview, reason: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline';">
  <style>
    body {
      font-family: var(--vscode-font-family);
      color: var(--vscode-foreground);
      background: var(--vscode-editor-background);
      display: flex;
      align-items: center;
      justify-content: center;
      height: 90vh;
      margin: 0;
    }
    .empty-state {
      text-align: center;
      opacity: .5;
      font-size: .95em;
    }
    .empty-state::before {
      content: "\\1F50A";
      display: block;
      font-size: 2em;
      margin-bottom: 12px;
    }
  </style>
</head>
<body>
  <div class="empty-state"><p>${esc(reason)}</p></div>
</body>
</html>`;
}

function buildHtml(items: ScreenReaderAnnouncement[], filePath: string, _webview: vscode.Webview): string {
  const issueCount = items.filter(i => i.hasIssue).length;
  const nonce = getNonce();

  const rows = items.map((a, idx) => {
    const cls = a.hasIssue ? 'issue' : '';
    const icon = a.hasIssue ? '&#9888;' : '&#128266;';
    const issueTag = a.hasIssue && a.issueMessage
      ? `<div class="issue-msg">${esc(a.issueMessage)}</div>`
      : '';

    return `
      <tr class="${cls}" data-idx="${idx}">
        <td class="idx">${idx + 1}</td>
        <td class="icon">${icon}</td>
        <td>
          <div class="announcement">${esc(a.announcement)}</div>
          <div class="meta">
            <span class="element">${esc(a.element)}</span>
            <span class="role">${esc(a.role)}</span>
            <span class="loc">line ${a.line + 1}</span>
          </div>
          ${issueTag}
        </td>
        <td class="play-cell">
          <button class="play-btn" data-idx="${idx}" title="Speak this announcement">&#9654;</button>
        </td>
      </tr>`;
  }).join('');

  // JSON-encode announcements for the speech script
  const announcementsJson = JSON.stringify(items.map(a => a.announcement));

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
  <title>Screen Reader Preview</title>
  <style>
    :root {
      --card-bg: var(--vscode-editor-inactiveSelectionBackground);
      --border: var(--vscode-panel-border);
      --green: var(--vscode-charts-green, #89d185);
      --orange: var(--vscode-charts-orange, #cca700);
      --blue: var(--vscode-charts-blue, #6fc3df);
      --red: var(--vscode-charts-red, #f14c4c);
      --radius: 6px;
    }
    * { box-sizing: border-box; }
    body { font-family: var(--vscode-font-family); color: var(--vscode-foreground); background: var(--vscode-editor-background); padding: 20px; margin: 0; line-height: 1.5; }
    h1 { font-size: 1.3em; margin: 0 0 4px; }
    .subtitle { opacity: .6; font-size: .85em; margin-bottom: 16px; }
    .summary { display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
    .summary-item { text-align: center; min-width: 80px; flex: 1; padding: 12px 10px; background: var(--card-bg); border-radius: var(--radius); border: 1px solid var(--border); transition: transform .15s; }
    .summary-item:hover { transform: translateY(-2px); }
    .summary-item .number { font-size: 1.6em; font-weight: bold; }
    .summary-item .label { font-size: .78em; opacity: .6; margin-top: 4px; text-transform: uppercase; letter-spacing: .3px; }
    .ok .number { color: var(--green); }
    .warn .number { color: var(--orange); }
    table { width: 100%; border-collapse: collapse; }
    tr { border-bottom: 1px solid var(--border); transition: background .15s; }
    tr:hover { background: var(--card-bg); }
    tr.issue { background: rgba(255, 80, 80, 0.07); }
    tr.speaking { background: rgba(80, 160, 255, 0.15); }
    td { padding: 8px 6px; vertical-align: top; }
    .idx { width: 28px; opacity: .45; font-size: .85em; text-align: right; padding-right: 10px; }
    .icon { width: 22px; font-size: 1.1em; }
    .announcement { font-weight: 500; margin-bottom: 3px; }
    .meta { display: flex; gap: 10px; font-size: .8em; opacity: .6; }
    .element { font-family: var(--vscode-editor-font-family, monospace); }
    .role { background: var(--vscode-badge-background); color: var(--vscode-badge-foreground); padding: 1px 6px; border-radius: 8px; font-size: .85em; }
    .loc { margin-left: auto; }
    .issue-msg { margin-top: 4px; font-size: .82em; color: var(--vscode-errorForeground); }
    .empty { text-align: center; padding: 40px 20px; opacity: .5; font-size: .9em; }

    /* Voice controls */
    .voice-toolbar { display: flex; flex-direction: column; gap: 10px; margin-bottom: 14px; padding: 12px 14px; background: var(--card-bg); border-radius: var(--radius); border: 1px solid var(--border); }
    .voice-toolbar .toolbar-row { display: flex; gap: 8px; align-items: center; }
    .voice-toolbar button { padding: 7px 16px; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;
      font-family: inherit; font-size: .85em; background: var(--vscode-button-background); color: var(--vscode-button-foreground); transition: opacity .15s, background .15s, transform .1s; }
    .voice-toolbar button:hover { opacity: .85; }
    .voice-toolbar button:active { transform: scale(.97); }
    .voice-toolbar button:focus-visible { outline: 2px solid var(--blue); outline-offset: 2px; }
    .voice-toolbar button.secondary { background: transparent; color: var(--vscode-foreground); border-color: var(--border); }
    .voice-toolbar button.secondary:hover { background: var(--vscode-list-hoverBackground); }
    .voice-toolbar button.active { background: var(--red); border-color: var(--red); }
    .voice-toolbar .spacer { flex: 1; }
    .voice-toolbar label { font-size: .78em; opacity: .5; text-transform: uppercase; letter-spacing: .3px; white-space: nowrap; }
    .voice-toolbar select { font-size: .82em; font-family: inherit; padding: 4px 8px; border: 1px solid var(--border); border-radius: 4px;
      background: var(--vscode-input-background); color: var(--vscode-input-foreground); max-width: 220px; min-width: 0; flex: 1; cursor: pointer; }
    .voice-toolbar select:focus-visible { outline: 2px solid var(--blue); outline-offset: 1px; }
    .voice-toolbar input[type="range"] { flex: 1; max-width: 120px; min-width: 60px; accent-color: var(--blue); cursor: pointer; }
    .rate-display { font-size: .82em; font-weight: 600; opacity: .8; min-width: 32px; text-align: center; font-variant-numeric: tabular-nums; }

    .play-cell { width: 36px; text-align: center; }
    .play-btn { background: transparent; border: 1px solid var(--border); border-radius: 4px; cursor: pointer;
      color: var(--vscode-foreground); font-size: .9em; padding: 4px 8px; opacity: .7; transition: opacity .15s, background .15s; }
    .play-btn:hover { opacity: 1; background: var(--vscode-button-background); color: var(--vscode-button-foreground); }
    .play-btn:focus-visible { outline: 2px solid var(--blue); outline-offset: 2px; }
  </style>
</head>
<body>
  <h1>&#128266; Screen Reader Preview</h1>
  <div class="subtitle">${esc(filePath)}</div>

  <div class="summary">
    <div class="summary-item ${issueCount === 0 ? 'ok' : ''}">
      <div class="number">${items.length}</div>
      <div class="label">Elements</div>
    </div>
    <div class="summary-item ok">
      <div class="number">${items.length - issueCount}</div>
      <div class="label">Accessible</div>
    </div>
    <div class="summary-item ${issueCount > 0 ? 'warn' : 'ok'}">
      <div class="number">${issueCount}</div>
      <div class="label">Missing Names</div>
    </div>
  </div>

  <div class="voice-toolbar">
    <div class="toolbar-row">
      <button id="playAll" title="Read all announcements sequentially">&#9654; Play All</button>
      <button id="stopBtn" class="secondary" title="Stop speaking">&#9632; Stop</button>
    </div>
    <div class="toolbar-row">
      <label for="voiceSelect">Voice</label>
      <select id="voiceSelect"></select>
      <label for="rateSlider">Speed</label>
      <input id="rateSlider" type="range" min="0.5" max="2" step="0.1" value="1" />
      <span id="rateDisplay" class="rate-display">1.0x</span>
    </div>
  </div>

  ${items.length === 0
    ? '<p class="empty">No semantic or interactive elements found in this file.</p>'
    : `<table><tbody>${rows}</tbody></table>`}

  <script nonce="${nonce}">
    const announcements = ${announcementsJson};
    let currentUtterance = null;
    let playAllIndex = -1;
    let isPlayingAll = false;

    // Populate voice list
    const voiceSelect = document.getElementById('voiceSelect');
    const rateSlider = document.getElementById('rateSlider');
    const rateDisplay = document.getElementById('rateDisplay');

    function populateVoices() {
      const voices = speechSynthesis.getVoices();
      voiceSelect.innerHTML = '';
      const defaultVoices = voices.filter(v => v.lang.startsWith('en'));
      const voicesToShow = defaultVoices.length > 0 ? defaultVoices : voices;
      voicesToShow.forEach((voice, i) => {
        const opt = document.createElement('option');
        opt.value = String(i);
        opt.textContent = voice.name + ' (' + voice.lang + ')';
        if (voice.default) opt.selected = true;
        voiceSelect.appendChild(opt);
      });
    }

    if (speechSynthesis.getVoices().length > 0) {
      populateVoices();
    }
    speechSynthesis.onvoiceschanged = populateVoices;

    rateSlider.addEventListener('input', () => {
      rateDisplay.textContent = parseFloat(rateSlider.value).toFixed(1) + 'x';
    });

    function getSelectedVoice() {
      const voices = speechSynthesis.getVoices();
      const defaultVoices = voices.filter(v => v.lang.startsWith('en'));
      const voicesToShow = defaultVoices.length > 0 ? defaultVoices : voices;
      const idx = parseInt(voiceSelect.value, 10);
      return voicesToShow[idx] || null;
    }

    function highlightRow(idx) {
      document.querySelectorAll('tr.speaking').forEach(r => r.classList.remove('speaking'));
      if (idx >= 0) {
        const row = document.querySelector('tr[data-idx="' + idx + '"]');
        if (row) row.classList.add('speaking');
      }
    }

    function speak(text, idx, onEnd) {
      speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = parseFloat(rateSlider.value);
      const voice = getSelectedVoice();
      if (voice) utter.voice = voice;
      highlightRow(idx);
      utter.onend = () => {
        highlightRow(-1);
        if (onEnd) onEnd();
      };
      utter.onerror = () => {
        highlightRow(-1);
        if (onEnd) onEnd();
      };
      currentUtterance = utter;
      speechSynthesis.speak(utter);
    }

    // Individual play buttons
    document.querySelectorAll('.play-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        isPlayingAll = false;
        const idx = parseInt(btn.dataset.idx, 10);
        speak(announcements[idx], idx, null);
      });
    });

    // Play All button
    document.getElementById('playAll').addEventListener('click', () => {
      if (announcements.length === 0) return;
      isPlayingAll = true;
      playAllIndex = 0;
      const playAllBtn = document.getElementById('playAll');
      playAllBtn.classList.add('active');
      playAllBtn.textContent = '... Playing';

      function playNext() {
        if (!isPlayingAll || playAllIndex >= announcements.length) {
          isPlayingAll = false;
          playAllIndex = -1;
          playAllBtn.classList.remove('active');
          playAllBtn.textContent = '\\u25B6 Play All';
          highlightRow(-1);
          return;
        }
        speak(announcements[playAllIndex], playAllIndex, () => {
          playAllIndex++;
          playNext();
        });
      }
      playNext();
    });

    // Stop button
    document.getElementById('stopBtn').addEventListener('click', () => {
      isPlayingAll = false;
      speechSynthesis.cancel();
      highlightRow(-1);
      const playAllBtn = document.getElementById('playAll');
      playAllBtn.classList.remove('active');
      playAllBtn.textContent = '\\u25B6 Play All';
    });
  </script>
</body>
</html>`;
}
