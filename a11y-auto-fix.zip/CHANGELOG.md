# Changelog

## [0.3.0] - 2026-04-02

### Added

- **Confidence & Reasoning for all fixes** — Every fix (AI and static) now shows a confidence score (0–100%), color-coded risk badge (green/orange/red), detailed reasoning, and caveats
- **axe-core integration** — Fixes are cross-validated against axe-core rule metadata; impact levels, WCAG tags, and documentation links are displayed in fix previews
- **Voice simulation** in Screen Reader Preview — Play All, per-row Play, Stop controls, voice selector, and speed slider using Web Speech API
- **Bulk AI Fix Workspace** (`a11y.bulkAiFix`) — AI-generate fixes for all files across the workspace; each file is scanned first and skipped if clean
- **Static Fix Current File** (`a11y.bulkFixFile`) — Preview and apply all deterministic fixes for the active file with the risk-aware preview panel
- **Per-rule static fix risk profiles** — Each rule has a calibrated confidence score (45–95%) with specific caveats (e.g., empty `aria-label` placeholder vs. deterministic `lang="en"`)
- **Risk-aware Bulk Fix Preview Panel** — Risk summary banner, confidence distribution chart, "Select Safe Only" button, low-confidence fixes start unchecked, modal confirmation before applying risky changes

### Changed

- Quick fix action titles now show confidence percentage (e.g., `[95%] Add lang="en"`)
- AI fix diff preview now shows confidence badge, reasoning, and axe-core metadata per change
- Publisher updated from `lockton` to `garvit-magoo`

### Fixed

- Screen Reader Preview "No active file" when clicking Play All (webview was stealing focus from text editor)

### Removed

- **Bulk Fix Entire Workspace** (static) — Replaced by the safer per-file static fix and workspace-wide AI bulk fix

## [0.2.0] - 2026-03-20

### Added

- **5 new WCAG 2.1 rules**: `autocomplete-valid` (1.3.5), `no-positive-tabindex` (2.4.3), `focus-visible` (2.4.7), `page-title` (2.4.2), `no-mouse-only-hover` (1.4.13)
- **Keyboard shortcuts**: `Ctrl+Alt+A` (scan file), `Ctrl+Alt+R` (report), `Ctrl+Alt+F` (bulk fix), `Ctrl+Alt+Shift+A` (scan workspace)
- **Workspace scan progress** with file-by-file progress indicator and cancellation support
- **Detailed skip reporting** for bulk fix — skipped changes logged to Output channel with file, line, and rule
- **Status bar severity breakdown** — tooltip now shows error/warning/info counts

### Improved

- Screen reader preview panel now debounces on text changes (500ms) to prevent typing lag
- Bulk fix in file goes directly to preview panel (no intermediate dropdown)
- Git comparison is now cancellable with 10s timeout per file to prevent hangs

## [0.1.0] - 2025-01-01

### Added

- **AST-based accessibility scanning** for React/JSX/TSX files
- **8 built-in rules**: img-alt, button-label, aria-role, form-label, click-key-events, aria-pattern, color-contrast, heading-order
- **AI-powered fix suggestions** via OpenAI or Azure OpenAI
- **Screen reader text preview** with simulated announcements
- **Accessibility score** in the status bar (0–100)
- **Auto-generate accessibility tests** from detected issues
- **Git regression tracking** — compare accessibility between commits
- **CI/CD export** — SARIF and JSON report formats
- **Real-time scanning** with debounced diagnostics on file change
- **Quick fixes** for every rule via VS Code Code Actions
- **Configuration** support via `.a11yrc.json` (enable/disable rules, exclude files)
- **Secure API key storage** using VS Code SecretStorage
- **Webview report panel** with issue visualization
