import * as vscode from 'vscode';
import type { A11yChange } from '../ai/fullFileFix';
import { updateDiagnostics } from '../diagnostics';
import { A11yReportPanel } from './reportPanel';
import { escapeHtml as esc, getNonce } from './utils';

/** A bulk fix change grouped by file. */
export interface BulkFixFileEntry {
  uri: vscode.Uri;
  relativePath: string;
  changes: A11yChange[];
}

export interface BulkFixResult {
  files: BulkFixFileEntry[];
}

/**
 * Webview panel that previews bulk-fix changes across one or more files,
 * letting the user accept/reject individual changes before applying.
 */
export class BulkFixPreviewPanel {
  public static currentPanel: BulkFixPreviewPanel | undefined;

  private readonly panel: vscode.WebviewPanel;
  private result: BulkFixResult;
  private disposables: vscode.Disposable[] = [];

  private constructor(panel: vscode.WebviewPanel, result: BulkFixResult) {
    this.panel = panel;
    this.result = result;

    this.panel.webview.html = this.buildHtml();

    this.panel.webview.onDidReceiveMessage(
      (msg) => this.handleMessage(msg),
      null,
      this.disposables,
    );

    this.panel.onDidDispose(() => this.dispose(), null, this.disposables);
  }

  public static createOrShow(result: BulkFixResult): void {
    const column = vscode.ViewColumn.Beside;

    if (BulkFixPreviewPanel.currentPanel) {
      BulkFixPreviewPanel.currentPanel.panel.dispose();
    }

    const totalChanges = result.files.reduce((sum, f) => sum + f.changes.length, 0);
    const panel = vscode.window.createWebviewPanel(
      'a11yBulkFixPreview',
      `A11y Bulk Fix (${totalChanges} changes)`,
      column,
      { enableScripts: true, retainContextWhenHidden: true },
    );

    BulkFixPreviewPanel.currentPanel = new BulkFixPreviewPanel(panel, result);
  }

  /* ── Message handling ──────────────────────────────── */

  private async handleMessage(msg: any): Promise<void> {
    switch (msg.type) {
      case 'applySelected': {
        const accepted: string[] = msg.accepted; // "fileIdx-changeId"
        await this.applyChanges(accepted);
        break;
      }
      case 'applyAll': {
        const allKeys: string[] = [];
        this.result.files.forEach((f, fi) => {
          f.changes.forEach(c => allKeys.push(`${fi}-${c.id}`));
        });
        await this.applyChanges(allKeys);
        break;
      }
      case 'dismiss':
        this.panel.dispose();
        break;
      case 'openFile': {
        if (msg.uri) {
          try {
            const uri = vscode.Uri.parse(msg.uri);
            const doc = await vscode.workspace.openTextDocument(uri);
            await vscode.window.showTextDocument(doc, vscode.ViewColumn.One);
          } catch { /* file may no longer exist */ }
        }
        break;
      }
    }
  }

  private async applyChanges(acceptedKeys: string[]): Promise<void> {
    if (acceptedKeys.length === 0) {
      vscode.window.showInformationMessage('A11y Scanner: No changes selected.');
      return;
    }

    // Group accepted changes by file index
    const groupedByFile = new Map<number, number[]>();
    for (const key of acceptedKeys) {
      const [fi, cid] = key.split('-').map(Number);
      if (!groupedByFile.has(fi)) { groupedByFile.set(fi, []); }
      groupedByFile.get(fi)!.push(cid);
    }

    const edit = new vscode.WorkspaceEdit();
    let appliedCount = 0;
    const skippedDetails: string[] = [];

    for (const [fileIdx, changeIds] of groupedByFile) {
      const entry = this.result.files[fileIdx];
      const document = await vscode.workspace.openTextDocument(entry.uri);

      const accepted = entry.changes
        .filter(c => changeIds.includes(c.id))
        .sort((a, b) => b.startLine - a.startLine); // bottom-up

      for (const change of accepted) {
        const startLine = change.startLine - 1;
        const endLine = Math.min(change.endLine - 1, document.lineCount - 1);
        const startPos = new vscode.Position(startLine, 0);
        const endPos = document.lineAt(endLine).range.end;
        const rangeToReplace = new vscode.Range(startPos, endPos);

        const currentText = document.getText(rangeToReplace);
        if (currentText.trim() !== change.original.trim()) {
          skippedDetails.push(`${entry.relativePath}:${change.startLine} [${change.rule}] — source changed`);
          continue;
        }

        edit.replace(entry.uri, rangeToReplace, change.replacement);
        appliedCount++;
      }
    }

    if (appliedCount === 0) {
      const detail = skippedDetails.length > 0
        ? `Skipped:\n${skippedDetails.join('\n')}`
        : 'Files may have been modified.';
      vscode.window.showWarningMessage(
        `A11y Scanner: No changes could be applied. ${detail}`,
      );
      return;
    }

    const success = await vscode.workspace.applyEdit(edit);
    if (success) {
      let msg = `A11y Scanner: Applied ${appliedCount} fix(es) across ${groupedByFile.size} file(s).`;
      if (skippedDetails.length > 0) {
        msg += ` Skipped ${skippedDetails.length} (source changed).`;
        // Show detailed skip info in the output channel
        const channel = vscode.window.createOutputChannel('A11y Scanner');
        channel.appendLine(`--- Bulk Fix: ${skippedDetails.length} change(s) skipped ---`);
        for (const detail of skippedDetails) {
          channel.appendLine(`  ${detail}`);
        }
        channel.appendLine('---');
        channel.show(true);
      }
      vscode.window.showInformationMessage(msg);

      // Re-scan diagnostics for all affected files so squiggles + status bar update immediately
      for (const [fileIdx] of groupedByFile) {
        const entry = this.result.files[fileIdx];
        try {
          const doc = await vscode.workspace.openTextDocument(entry.uri);
          await updateDiagnostics(doc);
        } catch { /* file may have been closed */ }
      }

      // Refresh the report panel if it's open
      if (A11yReportPanel.currentPanel) {
        await A11yReportPanel.currentPanel.update();
      }

      this.panel.dispose();
    } else {
      vscode.window.showErrorMessage('A11y Scanner: Failed to apply changes.');
    }
  }

  /* ── HTML builder ──────────────────────────────────── */

  private buildHtml(): string {
    const nonce = getNonce();
    const totalChanges = this.result.files.reduce((sum, f) => sum + f.changes.length, 0);
    const totalFiles = this.result.files.length;

    const fileSections = this.result.files
      .map((entry, fi) => this.buildFileSection(entry, fi))
      .join('\n');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy"
        content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
  <title>A11y Bulk Fix Preview</title>
  <style>
    :root {
      --card-bg: var(--vscode-editor-inactiveSelectionBackground);
      --border: var(--vscode-panel-border);
      --green: var(--vscode-charts-green, #89d185);
      --red: var(--vscode-charts-red, #f14c4c);
      --blue: var(--vscode-charts-blue, #6fc3df);
    }
    body { font-family: var(--vscode-font-family); color: var(--vscode-foreground);
           background: var(--vscode-editor-background); padding: 16px; margin: 0; }
    h1 { font-size: 1.3em; margin: 0 0 4px; }
    .subtitle { opacity: .7; font-size: .85em; margin-bottom: 16px; }

    .toolbar { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; align-items: center; }
    .toolbar button { padding: 6px 14px; border: 1px solid var(--border); border-radius: 4px;
      cursor: pointer; font-family: inherit; font-size: .85em;
      background: var(--vscode-button-background); color: var(--vscode-button-foreground); }
    .toolbar button:hover { opacity: .85; }
    .toolbar button.secondary { background: transparent; color: var(--vscode-foreground); }
    .toolbar .spacer { flex: 1; }
    .count { font-size: .85em; opacity: .7; line-height: 1; }

    /* file section */
    .file-section { margin-bottom: 20px; border: 1px solid var(--border); border-radius: 6px; overflow: hidden; }
    .file-header { display: flex; align-items: center; gap: 10px; padding: 10px 12px;
                   background: var(--vscode-sideBar-background, var(--card-bg));
                   cursor: pointer; user-select: none; font-weight: 600; font-size: .95em; }
    .file-header:hover { opacity: .9; }
    .file-header .file-checkbox { width: 18px; height: 18px; accent-color: var(--green); cursor: pointer; }
    .file-header .file-path { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; flex: 1; cursor: pointer; }
    .file-header .file-path:hover { text-decoration: underline; color: var(--vscode-textLink-foreground); }
    .file-header .file-count { opacity: .6; font-weight: 400; font-size: .82em; flex-shrink: 0; }
    .file-body { padding: 0 8px 8px; }

    /* change card */
    .change-card { border: 1px solid var(--border); border-radius: 6px; margin: 8px 0; overflow: hidden; }
    .change-header { display: flex; align-items: center; gap: 10px; padding: 8px 12px;
                     background: var(--card-bg); cursor: pointer; user-select: none; }
    .change-header:hover { opacity: .9; }
    .change-header .checkbox { width: 18px; height: 18px; accent-color: var(--green); cursor: pointer; }
    .change-header .rule { background: var(--vscode-badge-background); color: var(--vscode-badge-foreground);
                           padding: 1px 8px; border-radius: 8px; font-size: .78em; }
    .change-header .lines { opacity: .6; font-size: .82em; margin-left: auto; }
    .explanation { padding: 6px 12px 8px; font-size: .85em; opacity: .8; border-bottom: 1px solid var(--border); }

    .diff { display: grid; grid-template-columns: 1fr 1fr; font-family: var(--vscode-editor-font-family, monospace);
            font-size: .82em; line-height: 1.5; }
    .diff-label { padding: 4px 12px; font-weight: 600; font-size: .78em; text-transform: uppercase; opacity: .6;
                  border-bottom: 1px solid var(--border); }
    .diff-label.before { border-right: 1px solid var(--border); }
    .diff-code { padding: 8px 12px; white-space: pre-wrap; word-break: break-word; overflow-x: auto; }
    .diff-code.before { background: rgba(255,80,80,0.06); border-right: 1px solid var(--border); }
    .diff-code.after  { background: rgba(80,200,80,0.06); }

    .change-card.accepted { border-color: var(--green); }
    .change-card.rejected { opacity: .5; }
  </style>
</head>
<body>
  <h1>A11y Bulk Fix Preview</h1>
  <div class="subtitle">${totalChanges} proposed change(s) across ${totalFiles} file(s)</div>

  <div class="toolbar">
    <button id="selectAll">Select All</button>
    <button id="deselectAll" class="secondary">Deselect All</button>
    <span class="spacer"></span>
    <span id="selCount" class="count">0 selected</span>
    <button id="applySelected">Apply Selected</button>
    <button id="dismiss" class="secondary">Dismiss</button>
  </div>

  <div id="files">${fileSections}</div>

  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();

    function updateCount() {
      const checked = document.querySelectorAll('.change-checkbox:checked').length;
      document.getElementById('selCount').textContent = checked + ' selected';
    }

    function syncFileCheckbox(fileSection) {
      const fcb = fileSection.querySelector('.file-checkbox');
      const cbs = fileSection.querySelectorAll('.change-checkbox');
      const allChecked = [...cbs].every(cb => cb.checked);
      const someChecked = [...cbs].some(cb => cb.checked);
      fcb.checked = allChecked;
      fcb.indeterminate = someChecked && !allChecked;
    }

    // File-level select/deselect
    document.querySelectorAll('.file-section').forEach(fs => {
      const fcb = fs.querySelector('.file-checkbox');
      const header = fs.querySelector('.file-header');

      header.addEventListener('click', (e) => {
        if (e.target === fcb) return;
        fcb.checked = !fcb.checked;
        fcb.indeterminate = false;
        fs.querySelectorAll('.change-checkbox').forEach(cb => { cb.checked = fcb.checked; });
        fs.querySelectorAll('.change-card').forEach(card => {
          card.classList.toggle('accepted', fcb.checked);
          card.classList.toggle('rejected', !fcb.checked);
        });
        updateCount();
      });

      fcb.addEventListener('change', () => {
        fcb.indeterminate = false;
        fs.querySelectorAll('.change-checkbox').forEach(cb => { cb.checked = fcb.checked; });
        fs.querySelectorAll('.change-card').forEach(card => {
          card.classList.toggle('accepted', fcb.checked);
          card.classList.toggle('rejected', !fcb.checked);
        });
        updateCount();
      });
    });

    // Individual change checkboxes
    document.querySelectorAll('.change-card').forEach(card => {
      const hdr = card.querySelector('.change-header');
      const cb = card.querySelector('.change-checkbox');

      hdr.addEventListener('click', (e) => {
        if (e.target === cb) return;
        cb.checked = !cb.checked;
        card.classList.toggle('accepted', cb.checked);
        card.classList.toggle('rejected', !cb.checked);
        syncFileCheckbox(card.closest('.file-section'));
        updateCount();
      });

      cb.addEventListener('change', () => {
        card.classList.toggle('accepted', cb.checked);
        card.classList.toggle('rejected', !cb.checked);
        syncFileCheckbox(card.closest('.file-section'));
        updateCount();
      });
    });

    document.getElementById('selectAll').addEventListener('click', () => {
      document.querySelectorAll('.change-checkbox, .file-checkbox').forEach(cb => {
        cb.checked = true; cb.indeterminate = false;
      });
      document.querySelectorAll('.change-card').forEach(c => {
        c.classList.add('accepted'); c.classList.remove('rejected');
      });
      updateCount();
    });

    document.getElementById('deselectAll').addEventListener('click', () => {
      document.querySelectorAll('.change-checkbox, .file-checkbox').forEach(cb => {
        cb.checked = false; cb.indeterminate = false;
      });
      document.querySelectorAll('.change-card').forEach(c => {
        c.classList.remove('accepted'); c.classList.add('rejected');
      });
      updateCount();
    });

    document.getElementById('applySelected').addEventListener('click', () => {
      const accepted = [];
      document.querySelectorAll('.change-checkbox:checked').forEach(cb => {
        accepted.push(cb.dataset.key);
      });
      vscode.postMessage({ type: 'applySelected', accepted });
    });

    document.getElementById('dismiss').addEventListener('click', () => {
      vscode.postMessage({ type: 'dismiss' });
    });

    // File name click → open file in editor
    document.querySelectorAll('.file-path').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        vscode.postMessage({ type: 'openFile', uri: el.dataset.uri });
      });
    });

    // Default: all selected
    document.querySelectorAll('.change-checkbox, .file-checkbox').forEach(cb => { cb.checked = true; });
    document.querySelectorAll('.change-card').forEach(c => c.classList.add('accepted'));
    updateCount();
  </script>
</body>
</html>`;
  }

  private buildFileSection(entry: BulkFixFileEntry, fileIdx: number): string {
    const cards = entry.changes.map(c => this.buildChangeCard(c, fileIdx)).join('\n');
    return `
    <div class="file-section" data-fi="${fileIdx}">
      <div class="file-header">
        <input type="checkbox" class="file-checkbox" checked />
        <span class="file-path" title="${esc(entry.relativePath)}" data-uri="${esc(entry.uri.toString())}">${esc(entry.relativePath)}</span>
        <span class="file-count">${entry.changes.length} change(s)</span>
      </div>
      <div class="file-body">${cards}</div>
    </div>`;
  }

  private buildChangeCard(change: A11yChange, fileIdx: number): string {
    const key = `${fileIdx}-${change.id}`;
    return `
    <div class="change-card" data-key="${key}">
      <div class="change-header">
        <input type="checkbox" class="checkbox change-checkbox" data-key="${key}" checked />
        <strong>${esc(change.explanation)}</strong>
        <span class="rule">${esc(change.rule)}</span>
        <span class="lines">Lines ${change.startLine}\u2013${change.endLine}</span>
      </div>
      <div class="explanation">${esc(change.explanation)}</div>
      <div class="diff">
        <div class="diff-label before">Before</div>
        <div class="diff-label">After</div>
        <div class="diff-code before">${esc(change.original)}</div>
        <div class="diff-code after">${esc(change.replacement)}</div>
      </div>
    </div>`;
  }

  private dispose(): void {
    BulkFixPreviewPanel.currentPanel = undefined;
    this.panel.dispose();
    this.disposables.forEach(d => d.dispose());
  }
}

