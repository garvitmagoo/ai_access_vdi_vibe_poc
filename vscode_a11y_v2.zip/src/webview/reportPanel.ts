import * as vscode from 'vscode';
import { scanForA11yIssues } from '../scanner/astScanner';
import type { A11yIssue } from '../types';
import { escapeHtml, getNonce } from './utils';

/**
 * Generates an HTML report of accessibility issues across the workspace.
 */
export class A11yReportPanel {
  public static currentPanel: A11yReportPanel | undefined;
  private readonly panel: vscode.WebviewPanel;
  private disposables: vscode.Disposable[] = [];

  private constructor(panel: vscode.WebviewPanel) {
    this.panel = panel;
    this.panel.webview.html = this.getLoadingHtml();
    this.panel.webview.onDidReceiveMessage(
      (msg) => this.handleMessage(msg),
      null,
      this.disposables,
    );
    this.panel.onDidDispose(() => this.dispose(), null, this.disposables);
  }

  private async handleMessage(msg: any): Promise<void> {
    if (msg.type === 'openFile' && msg.uri) {
      try {
        const uri = vscode.Uri.parse(msg.uri);
        const doc = await vscode.workspace.openTextDocument(uri);
        await vscode.window.showTextDocument(doc, vscode.ViewColumn.One);
      } catch { /* file may no longer exist */ }
    }
  }

  private getLoadingHtml(): string {
    return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline';"><style>body{font-family:var(--vscode-font-family);color:var(--vscode-foreground);background:var(--vscode-editor-background);display:flex;align-items:center;justify-content:center;height:90vh;opacity:.6;}</style>
</head><body><p>Scanning workspace…</p></body></html>`;
  }

  public static async createOrShow(_context: vscode.ExtensionContext): Promise<void> {
    const column = vscode.ViewColumn.Beside;

    if (A11yReportPanel.currentPanel) {
      A11yReportPanel.currentPanel.panel.reveal(column);
      await A11yReportPanel.currentPanel.update();
      return;
    }

    const panel = vscode.window.createWebviewPanel(
      'a11yReport',
      'A11y Accessibility Report',
      column,
      {
        enableScripts: true,
        retainContextWhenHidden: true,
      },
    );

    A11yReportPanel.currentPanel = new A11yReportPanel(panel);
    await A11yReportPanel.currentPanel.update();
  }

  public async update(): Promise<void> {
    const files = await vscode.workspace.findFiles('**/*.{tsx,jsx}', '**/node_modules/**');

    const issuesByFile: { file: string; uri: string; issues: { message: string; rule: string; severity: string; line: number }[] }[] = [];
    let totalIssues = 0;
    const ruleCount: Record<string, number> = {};

    for (const fileUri of files) {
      const document = await vscode.workspace.openTextDocument(fileUri);
      const issues = scanForA11yIssues(document.getText(), document.fileName);

      if (issues.length > 0) {
        const relativePath = vscode.workspace.asRelativePath(fileUri);
        issuesByFile.push({
          file: relativePath,
          uri: fileUri.toString(),
          issues: issues.map((i: A11yIssue) => ({ message: i.message, rule: i.rule, severity: i.severity, line: i.line + 1 })),
        });
        totalIssues += issues.length;
        issues.forEach((i: A11yIssue) => {
          ruleCount[i.rule] = (ruleCount[i.rule] || 0) + 1;
        });
      }
    }

    this.panel.webview.html = this.getHtml(issuesByFile, totalIssues, ruleCount, files.length);
  }

  private getHtml(
    issuesByFile: { file: string; uri: string; issues: { message: string; rule: string; severity: string; line: number }[] }[],
    totalIssues: number,
    ruleCount: Record<string, number>,
    totalFiles: number,
  ): string {
    const sortedRules = Object.entries(ruleCount).sort((a, b) => b[1] - a[1]);

    const fileRows = issuesByFile
      .sort((a, b) => b.issues.length - a.issues.length)
      .map(f => {
        const issueRows = f.issues.map(i => `
          <tr class="issue-row">
            <td class="severity ${i.severity}">${i.severity.toUpperCase()}</td>
            <td>Line ${i.line}</td>
            <td>${escapeHtml(i.message)}</td>
            <td><code>${i.rule}</code></td>
          </tr>
        `).join('');

        return `
          <div class="file-section">
            <div class="file-header" data-toggle="collapse">
              <span class="chevron">&#9660;</span>
              <strong title="${escapeHtml(f.file)}" class="file-name" data-uri="${escapeHtml(f.uri)}">${escapeHtml(f.file)}</strong>
              <span class="badge">${f.issues.length}</span>
            </div>
            <table class="issues-table">
              <tbody>${issueRows}</tbody>
            </table>
          </div>
        `;
      }).join('');

    const ruleRows = sortedRules.map(([rule, count]) => `
      <tr><td><code>${rule}</code></td><td>${count}</td></tr>
    `).join('');

    const nonce = getNonce();

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
  <title>A11y Report</title>
  <style>
    body { font-family: var(--vscode-font-family); color: var(--vscode-foreground); background: var(--vscode-editor-background); padding: 16px; margin: 0; overflow-x: hidden; }
    h1 { font-size: 1.4em; margin-bottom: 8px; }
    h2 { font-size: 1.15em; margin: 24px 0 10px; }

    /* summary cards */
    .summary { display: flex; gap: 16px; margin-bottom: 24px; padding: 14px 16px; background: var(--vscode-editor-inactiveSelectionBackground); border-radius: 6px; flex-wrap: wrap; }
    .summary-item { text-align: center; min-width: 70px; flex: 1; }
    .summary-item .number { font-size: 2em; font-weight: bold; color: var(--vscode-foreground); }
    .summary-item .label { font-size: 0.82em; opacity: 0.7; margin-top: 2px; }

    /* rule table */
    .rule-table { width: 100%; max-width: 500px; border-collapse: collapse; margin-bottom: 24px; }
    .rule-table td { padding: 6px 12px; border-bottom: 1px solid var(--vscode-panel-border); }
    .rule-table td:last-child { text-align: right; font-weight: 600; min-width: 50px; }
    code { background: var(--vscode-textCodeBlock-background); padding: 2px 6px; border-radius: 3px; font-size: 0.88em; }

    /* file sections */
    .file-section { margin-bottom: 8px; border: 1px solid var(--vscode-panel-border); border-radius: 6px; overflow: hidden; }
    .file-section.collapsed .issues-table { display: none; }
    .file-section.collapsed .chevron { transform: rotate(-90deg); }
    .file-header { padding: 10px 12px; cursor: pointer; display: flex; align-items: center; gap: 8px; background: var(--vscode-sideBar-background, var(--vscode-editor-inactiveSelectionBackground)); user-select: none; }
    .file-header:hover { background: var(--vscode-list-hoverBackground); }
    .file-header strong { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 0.92em; }
    .file-header strong.file-name { cursor: pointer; }
    .file-header strong.file-name:hover { text-decoration: underline; color: var(--vscode-textLink-foreground); }
    .chevron { display: inline-block; transition: transform 0.2s; font-size: 0.7em; flex-shrink: 0; }
    .badge { background: var(--vscode-badge-background); color: var(--vscode-badge-foreground); padding: 2px 8px; border-radius: 10px; font-size: 0.8em; flex-shrink: 0; }

    /* issue rows */
    .issues-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
    .issue-row td { padding: 8px 10px; border-top: 1px solid var(--vscode-panel-border); font-size: 0.88em; vertical-align: top; word-wrap: break-word; overflow-wrap: break-word; }
    .issue-row td:nth-child(1) { width: 72px; }
    .issue-row td:nth-child(2) { width: 60px; white-space: nowrap; }
    .issue-row td:nth-child(3) { }
    .issue-row td:nth-child(4) { width: 120px; }
    .severity { font-weight: bold; font-size: 0.78em; text-transform: uppercase; letter-spacing: 0.5px; }
    .severity.error { color: #f48771; }
    .severity.warning { color: #cca700; }
    .severity.info { color: #75beff; }
    .severity.hint { color: #89d185; }
  </style>
</head>
<body>
  <h1>Accessibility Report</h1>

  <div class="summary">
    <div class="summary-item">
      <div class="number">${totalIssues}</div>
      <div class="label">Total Issues</div>
    </div>
    <div class="summary-item">
      <div class="number">${issuesByFile.length}</div>
      <div class="label">Files with Issues</div>
    </div>
    <div class="summary-item">
      <div class="number">${totalFiles}</div>
      <div class="label">Files Scanned</div>
    </div>
    <div class="summary-item">
      <div class="number">${sortedRules.length}</div>
      <div class="label">Rule Types</div>
    </div>
  </div>

  <h2>Issues by Rule</h2>
  <table class="rule-table">
    <tbody>${ruleRows}</tbody>
  </table>

  <h2>Issues by File</h2>
  ${fileRows || '<p>No accessibility issues found.</p>'}
  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();

    document.querySelectorAll('[data-toggle="collapse"]').forEach(function(el) {
      el.addEventListener('click', function() {
        this.parentElement.classList.toggle('collapsed');
      });
    });

    document.querySelectorAll('.file-name').forEach(function(el) {
      el.addEventListener('click', function(e) {
        e.stopPropagation();
        vscode.postMessage({ type: 'openFile', uri: el.dataset.uri });
      });
    });
  </script>
</body>
</html>`;
  }

  private dispose(): void {
    A11yReportPanel.currentPanel = undefined;
    this.panel.dispose();
    this.disposables.forEach(d => d.dispose());
  }
}
