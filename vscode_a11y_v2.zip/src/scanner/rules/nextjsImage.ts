import * as ts from 'typescript';
import type { A11yIssue } from '../../types';

/**
 * Rule: nextjs-image-alt
 * Next.js <Image> component (from next/image) must have an alt attribute.
 * Decorative images should use alt="" explicitly.
 */
export function checkNextjsImageAlt(node: ts.Node, sourceFile: ts.SourceFile): A11yIssue[] {
  const issues: A11yIssue[] = [];

  if (ts.isJsxSelfClosingElement(node) || ts.isJsxOpeningElement(node)) {
    const tagName = node.tagName.getText(sourceFile);
    if (tagName === 'Image') {
      const attrs = node.attributes.properties;

      const hasAlt = attrs.some(
        attr => ts.isJsxAttribute(attr) && attr.name.getText(sourceFile) === 'alt'
      );

      if (!hasAlt) {
        const { line, character } = sourceFile.getLineAndCharacterOfPosition(node.getStart(sourceFile));
        issues.push({
          message: 'Next.js `<Image>` component must have an `alt` attribute. Use alt="" for decorative images.',
          rule: 'nextjs-image-alt',
          severity: 'error',
          line,
          column: character,
          snippet: node.getText(sourceFile),
        });
      }
    }
  }

  return issues;
}
