import * as vscode from 'vscode';
import { initDiagnostics, updateDiagnostics, scanWorkspace, clearDiagnosticData } from './diagnostics';
import { A11yCodeActionProvider, applyAiFixCommand, bulkFixRuleCommand, bulkFixWorkspaceCommand } from './codeActions';
import { A11yReportPanel } from './webview/reportPanel';
import { ScreenReaderPanel } from './webview/screenReaderPanel';
import { createStatusBarItem, updateStatusBarScore } from './statusBar';
import { generateA11yTests } from './testGenerator';
import { compareWithLastCommit } from './gitRegression';
import { exportSarif, exportJson } from './exportReport';
import { initAiProvider, setAiApiKey } from './ai/provider';
import { getFullFileFix } from './ai/fullFileFix';
import { DiffPreviewPanel } from './webview/diffPreviewPanel';
import { invalidateConfigCache } from './config';

export function activate(context: vscode.ExtensionContext): void {
  console.log('A11y Scanner extension activated');

  initDiagnostics(context);
  initAiProvider(context.secrets);

  const config = vscode.workspace.getConfiguration('a11y');

  if (config.get<boolean>('scanOnOpen', true)) {
    context.subscriptions.push(
      vscode.window.onDidChangeActiveTextEditor(editor => {
        if (editor) {
          updateDiagnostics(editor.document);
        }
      }),
    );
  }

  if (config.get<boolean>('scanOnSave', true)) {
    context.subscriptions.push(
      vscode.workspace.onDidSaveTextDocument(document => {
        updateDiagnostics(document);
      }),
    );
  }

  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(document => {
      updateDiagnostics(document);
    }),
  );

  const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument(event => {
      const key = event.document.uri.toString();
      const existing = debounceTimers.get(key);
      if (existing) { clearTimeout(existing); }
      debounceTimers.set(key, setTimeout(() => {
        debounceTimers.delete(key);
        updateDiagnostics(event.document);
      }, 500));
    }),
  );

  // Clean up debounce timers when documents close
  context.subscriptions.push(
    vscode.workspace.onDidCloseTextDocument(document => {
      const key = document.uri.toString();
      const timer = debounceTimers.get(key);
      if (timer) {
        clearTimeout(timer);
        debounceTimers.delete(key);
      }
    }),
  );

  if (vscode.window.activeTextEditor) {
    updateDiagnostics(vscode.window.activeTextEditor.document);
  }

  // Clean up diagnostic data when documents are closed
  context.subscriptions.push(
    vscode.workspace.onDidCloseTextDocument(document => {
      clearDiagnosticData(document.uri);
    }),
  );

  const configWatcher = vscode.workspace.createFileSystemWatcher('**/.a11yrc.json');
  configWatcher.onDidChange(() => invalidateConfigCache());
  configWatcher.onDidCreate(() => invalidateConfigCache());
  configWatcher.onDidDelete(() => invalidateConfigCache());
  context.subscriptions.push(configWatcher);

  createStatusBarItem(context);

  context.subscriptions.push(
    vscode.languages.onDidChangeDiagnostics(() => updateStatusBarScore()),
  );
  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor(() => updateStatusBarScore()),
  );

  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      [
        { language: 'typescriptreact' },
        { language: 'javascriptreact' },
      ],
      new A11yCodeActionProvider(),
      {
        providedCodeActionKinds: A11yCodeActionProvider.providedCodeActionKinds,
      },
    ),
  );

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.scanWorkspace', async () => {
      try {
        const totalIssues = await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: 'A11y Scanner: Scanning workspace…',
            cancellable: true,
          },
          async (progress, token) => {
            return await scanWorkspace(progress, token);
          },
        );
        vscode.window.showInformationMessage(
          `A11y Scanner: Found ${totalIssues} accessibility issue(s) across the workspace.`,
        );
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Unknown error';
        vscode.window.showErrorMessage(`A11y Scanner: Workspace scan failed \u2014 ${msg}`);
      }
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.showReport', async () => {
      await A11yReportPanel.createOrShow(context);
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.applyAiFix', async (uri: vscode.Uri, diagnostic: vscode.Diagnostic) => {
      await applyAiFixCommand(uri, diagnostic);
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.bulkFixRule', async (uri: vscode.Uri, ruleId: string) => {
      await bulkFixRuleCommand(uri, ruleId);
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.bulkFixWorkspace', async () => {
      await bulkFixWorkspaceCommand();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.screenReaderPreview', () => {
      ScreenReaderPanel.createOrShow();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.setApiKey', async () => {
      await setAiApiKey();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.generateTests', async () => {
      await generateA11yTests();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.fixFile', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showWarningMessage('A11y Scanner: No active file to fix.');
        return;
      }
      const document = editor.document;

      try {
        const result = await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: 'A11y Scanner: Generating AI fixes for entire file…',
            cancellable: false,
          },
          () => getFullFileFix(document),
        );

        if (result && result.changes.length > 0) {
          DiffPreviewPanel.createOrShow(document.uri, result);
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Unknown error';
        vscode.window.showErrorMessage(`A11y Scanner: ${msg}`);
      }
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.compareWithLastCommit', async () => {
      await compareWithLastCommit();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.exportSarif', async () => {
      await exportSarif();
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('a11y.exportJson', async () => {
      await exportJson();
    }),
  );
}

export function deactivate(): void {
  console.log('A11y Scanner extension deactivated');
}
