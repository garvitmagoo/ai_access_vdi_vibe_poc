import * as vscode from 'vscode';
import { getAiFix } from './ai/provider';
import type { A11yChange } from './ai/fullFileFix';
import { BulkFixPreviewPanel } from './webview/bulkFixPreviewPanel';
import type { BulkFixFileEntry } from './webview/bulkFixPreviewPanel';
import { getDiagnosticData } from './diagnostics';
import { scanForA11yIssues } from './scanner/astScanner';
import { loadConfig, applyConfig, isExcluded } from './config';
import { toVscodeSeverity } from './types';
import { VALID_ROLES } from './scanner/rules/ariaRole';
import { suggestAccessibleForeground } from './scanner/rules/colorContrast';

/**
 * Find the closing `>` or `/>` of an opening JSX tag on a line,
 * scanning forward from `tagStart` (the `<` position).
 * Skips over quoted strings and `{...}` JSX expressions so we
 * never match a `>` that lives inside an attribute value.
 *
 * Returns the index of `/` for self-closing `/>`, or the index of `>`
 * for a normal open tag. Returns -1 if the tag doesn't close on this line.
 */
function findOpeningTagClose(lineText: string, tagStart: number): number {
  let i = tagStart;

  // Skip '<'
  if (i < lineText.length && lineText[i] === '<') { i++; }

  // Skip tag name  (letters, digits, dots, dashes, underscores)
  while (i < lineText.length && /[a-zA-Z0-9._\-]/.test(lineText[i])) { i++; }

  // Walk through attributes, skipping strings and {expressions}
  let inString: string | false = false;
  let braceDepth = 0;

  while (i < lineText.length) {
    const ch = lineText[i];

    if (inString) {
      if (ch === inString && lineText[i - 1] !== '\\') {
        inString = false;
      }
    } else if (ch === '"' || ch === "'") {
      inString = ch;
    } else if (ch === '{') {
      braceDepth++;
    } else if (ch === '}') {
      braceDepth = Math.max(0, braceDepth - 1);
    } else if (braceDepth === 0) {
      // Self-closing />
      if (ch === '/' && i + 1 < lineText.length && lineText[i + 1] === '>') {
        return i;
      }
      // Normal close >
      if (ch === '>') {
        return i;
      }
    }

    i++;
  }

  return -1; // tag doesn't close on this line
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0) as number[]);
  for (let i = 0; i <= m; i++) { dp[i][0] = i; }
  for (let j = 0; j <= n; j++) { dp[0][j] = j; }
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

/**
 * Find the closest valid ARIA role by Levenshtein distance.
 */
function findClosestRole(invalid: string): string | null {
  let best: string | null = null;
  let bestDist = Infinity;
  for (const role of VALID_ROLES) {
    const dist = levenshtein(invalid, role);
    if (dist < bestDist) {
      bestDist = dist;
      best = role;
    }
  }
  // Only suggest if distance is reasonable (≤ half the length of the input)
  if (best && bestDist <= Math.max(3, Math.ceil(invalid.length / 2))) {
    return best;
  }
  return null;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Provides Quick Fix code actions for accessibility diagnostics.
 * When the user clicks the lightbulb on an a11y issue, this provider
 * offers an AI-powered fix and/or a manual fix suggestion.
 */
export class A11yCodeActionProvider implements vscode.CodeActionProvider {

  public static readonly providedCodeActionKinds = [
    vscode.CodeActionKind.QuickFix,
  ];

  async provideCodeActions(
    document: vscode.TextDocument,
    _range: vscode.Range,
    context: vscode.CodeActionContext,
  ): Promise<vscode.CodeAction[]> {
    const actions: vscode.CodeAction[] = [];

    // Collect all a11y diagnostics in the file for bulk fix
    const allDiagnostics = vscode.languages.getDiagnostics(document.uri)
      .filter(d => d.source === 'A11y Scanner');

    // Track which rules appear in the current selection for bulk fix offers
    const ruleCountsInFile = new Map<string, number>();
    for (const d of allDiagnostics) {
      const rule = extractRuleCode(d);
      if (rule) {
        ruleCountsInFile.set(rule, (ruleCountsInFile.get(rule) || 0) + 1);
      }
    }

    const offeredBulkRules = new Set<string>();

    for (const diagnostic of context.diagnostics) {
      if (diagnostic.source !== 'A11y Scanner') {
        continue;
      }

      // Add a manual/static quick fix based on the rule
      const staticFix = this.getStaticFix(document, diagnostic);
      if (staticFix) {
        actions.push(staticFix);
      }

      // Offer "Fix all X issues in file" if >1 issue of this rule exists and we have a static fix
      const rule = extractRuleCode(diagnostic);
      const count = rule ? (ruleCountsInFile.get(rule) || 0) : 0;
      if (rule && count > 1 && staticFix && !offeredBulkRules.has(rule)) {
        offeredBulkRules.add(rule);
        const bulkFix = new vscode.CodeAction(
          `A11y: Fix all ${count} "${rule}" issues in file`,
          vscode.CodeActionKind.QuickFix,
        );
        bulkFix.command = {
          command: 'a11y.bulkFixRule',
          title: `Fix all ${rule} issues`,
          arguments: [document.uri, rule],
        };
        actions.push(bulkFix);
      }

      // Add an AI-powered fix option
      const config = vscode.workspace.getConfiguration('a11y');
      if (config.get<string>('aiProvider', 'none') !== 'none') {
        const aiFix = new vscode.CodeAction(
          `A11y: AI Fix - ${diagnostic.message}`,
          vscode.CodeActionKind.QuickFix,
        );
        aiFix.diagnostics = [diagnostic];
        aiFix.command = {
          command: 'a11y.applyAiFix',
          title: 'Apply AI Accessibility Fix',
          arguments: [document.uri, diagnostic],
        };
        actions.push(aiFix);
      }
    }

    return actions;
  }

  private getStaticFix(document: vscode.TextDocument, diagnostic: vscode.Diagnostic): vscode.CodeAction | null {
    const rule = diagnostic.code as string;

    switch (rule) {
      case 'img-alt':
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'alt=""',
          'Add empty alt attribute (decorative image)',
        );

      case 'button-label':
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'aria-label=""',
          'Add aria-label attribute',
        );

      case 'form-label':
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'aria-label=""',
          'Add aria-label attribute',
        );

      case 'click-events-have-key-events':
        return this.createInsertAttributesFix(
          document,
          diagnostic,
          ['role="button"', 'tabIndex={0}', 'onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { /* handler */ } }}'],
          'Add keyboard support (role, tabIndex, onKeyDown)',
        );

      case 'aria-pattern': {
        const msg = diagnostic.message;
        if (msg.includes('aria-labelledby') || msg.includes('aria-label')) {
          return this.createInsertAttributeFix(
            document,
            diagnostic,
            'aria-label=""',
            'Add aria-label attribute',
          );
        }
        if (msg.includes('aria-expanded')) {
          return this.createInsertAttributeFix(
            document,
            diagnostic,
            'aria-expanded={false}',
            'Add aria-expanded attribute',
          );
        }
        if (msg.includes('aria-controls') || msg.includes('aria-selected')) {
          return this.createInsertAttributesFix(
            document,
            diagnostic,
            ['aria-controls=""', 'aria-selected={false}'],
            'Add aria-controls and aria-selected',
          );
        }
        return null;
      }

      case 'heading-order': {
        const data = getDiagnosticData(document.uri, diagnostic);
        const msg = diagnostic.message;

        if (data?.type === 'skipped' && data.currentTag && data.previousLevel) {
          const suggestedLevel = parseInt(data.previousLevel, 10) + 1;
          if (suggestedLevel <= 6) {
            return this.createReplaceHeadingFix(document, diagnostic, data.currentTag, `h${suggestedLevel}`);
          }
        } else if (data?.type === 'multiple-h1') {
          return this.createReplaceHeadingFix(document, diagnostic, 'h1', 'h2');
        } else if (data?.type === 'first-heading' && data.currentTag) {
          return this.createReplaceHeadingFix(document, diagnostic, data.currentTag, 'h1');
        }

        // Regex fallback for diagnostics without structured data
        const currentTagMatch = msg.match(/<(h[1-6])>/);
        if (currentTagMatch && msg.includes('skipped')) {
          const prevMatch = msg.match(/follows `<h(\d)>/);
          if (prevMatch) {
            const suggestedLevel = parseInt(prevMatch[1], 10) + 1;
            if (suggestedLevel <= 6) {
              return this.createReplaceHeadingFix(document, diagnostic, currentTagMatch[1], `h${suggestedLevel}`);
            }
          }
        }
        if (msg.includes('Multiple') && msg.includes('<h1>')) {
          return this.createReplaceHeadingFix(document, diagnostic, 'h1', 'h2');
        }
        if (msg.includes('First heading') && currentTagMatch) {
          return this.createReplaceHeadingFix(document, diagnostic, currentTagMatch[1], 'h1');
        }
        return null;
      }

      case 'aria-role': {
        const data = getDiagnosticData(document.uri, diagnostic);
        const invalidRole = data?.invalidRole ?? diagnostic.message.match(/Invalid ARIA role "([^"]+)"/)?.[1];
        if (invalidRole) {
          const closest = findClosestRole(invalidRole);
          if (closest) {
            return this.createReplaceRoleValueFix(document, diagnostic, invalidRole, closest);
          }
        }
        return null;
      }

      case 'color-contrast': {
        const data = getDiagnosticData(document.uri, diagnostic);
        const fg = data?.foreground ?? diagnostic.message.match(/foreground: "([^"]+)"/)?.[1];
        const bg = data?.background ?? diagnostic.message.match(/background: "([^"]+)"/)?.[1];
        if (fg && bg) {
          const fixedFg = suggestAccessibleForeground(fg, bg);
          if (fixedFg) {
            return this.createReplaceColorFix(document, diagnostic, fg, fixedFg);
          }
        }
        return null;
      }

      case 'nextjs-image-alt':
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'alt=""',
          'Add alt attribute to Next.js Image',
        );

      case 'nextjs-head-lang':
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'lang="en"',
          'Add lang attribute',
        );

      case 'nextjs-link-text':
        return this.createInsertAttributeFix(
          document,
          diagnostic,
          'aria-label=""',
          'Add aria-label to Next.js Link',
        );

      default:
        return null;
    }
  }

  private createInsertAttributeFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    attribute: string,
    title: string,
  ): vscode.CodeAction {
    const fix = new vscode.CodeAction(
      `A11y: ${title}`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const line = document.lineAt(diagnostic.range.start.line);
    const lineText = line.text;
    const tagStart = diagnostic.range.start.character;
    const insertIndex = findOpeningTagClose(lineText, tagStart);

    if (insertIndex !== -1) {
      const edit = new vscode.WorkspaceEdit();
      const insertPosition = new vscode.Position(diagnostic.range.start.line, insertIndex);
      edit.insert(document.uri, insertPosition, ` ${attribute} `);
      fix.edit = edit;
    }

    fix.isPreferred = true;
    return fix;
  }

  private createInsertAttributesFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    attributes: string[],
    title: string,
  ): vscode.CodeAction {
    const fix = new vscode.CodeAction(
      `A11y: ${title}`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const line = document.lineAt(diagnostic.range.start.line);
    const lineText = line.text;
    const tagStart = diagnostic.range.start.character;
    const insertIndex = findOpeningTagClose(lineText, tagStart);

    if (insertIndex !== -1) {
      const edit = new vscode.WorkspaceEdit();
      const insertPosition = new vscode.Position(diagnostic.range.start.line, insertIndex);
      edit.insert(document.uri, insertPosition, ` ${attributes.join(' ')} `);
      fix.edit = edit;
    }

    return fix;
  }

  private createReplaceHeadingFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    currentTag: string,
    suggestedTag: string,
  ): vscode.CodeAction {
    const fix = new vscode.CodeAction(
      `A11y: Change <${currentTag}> to <${suggestedTag}>`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const edit = new vscode.WorkspaceEdit();
    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;

    // Replace the opening tag
    const openIdx = lineText.indexOf(`<${currentTag}`);
    if (openIdx !== -1) {
      const openRange = new vscode.Range(lineNum, openIdx + 1, lineNum, openIdx + 1 + currentTag.length);
      edit.replace(document.uri, openRange, suggestedTag);
    }

    // Replace the closing tag on the same line (if present)
    const closeIdx = lineText.indexOf(`</${currentTag}>`);
    if (closeIdx !== -1) {
      const closeRange = new vscode.Range(lineNum, closeIdx + 2, lineNum, closeIdx + 2 + currentTag.length);
      edit.replace(document.uri, closeRange, suggestedTag);
    }

    fix.edit = edit;
    fix.isPreferred = true;
    return fix;
  }

  private createReplaceRoleValueFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    invalidRole: string,
    suggestedRole: string,
  ): vscode.CodeAction {
    const fix = new vscode.CodeAction(
      `A11y: Replace role="${invalidRole}" with "${suggestedRole}"`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const edit = new vscode.WorkspaceEdit();
    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;
    const idx = lineText.indexOf(`"${invalidRole}"`);
    if (idx !== -1) {
      const range = new vscode.Range(lineNum, idx + 1, lineNum, idx + 1 + invalidRole.length);
      edit.replace(document.uri, range, suggestedRole);
    }
    fix.edit = edit;
    fix.isPreferred = true;
    return fix;
  }

  private createReplaceColorFix(
    document: vscode.TextDocument,
    diagnostic: vscode.Diagnostic,
    originalColor: string,
    fixedColor: string,
  ): vscode.CodeAction {
    const fix = new vscode.CodeAction(
      `A11y: Adjust foreground color to "${fixedColor}" for contrast`,
      vscode.CodeActionKind.QuickFix,
    );
    fix.diagnostics = [diagnostic];

    const edit = new vscode.WorkspaceEdit();
    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;

    // Replace the color value in the style's color property
    const colorPattern = new RegExp(`(color:\\s*["'])${escapeRegExp(originalColor)}(["'])`, 'i');
    const match = lineText.match(colorPattern);
    if (match && match.index !== undefined) {
      const valueStart = match.index + match[1].length;
      const range = new vscode.Range(lineNum, valueStart, lineNum, valueStart + originalColor.length);
      edit.replace(document.uri, range, fixedColor);
    }
    fix.edit = edit;
    fix.isPreferred = true;
    return fix;
  }
}

/**
 * Command handler: applies an AI-generated fix for an accessibility issue.
 */
export async function applyAiFixCommand(uri: vscode.Uri, diagnostic: vscode.Diagnostic): Promise<void> {
  const document = await vscode.workspace.openTextDocument(uri);
  const lineText = document.lineAt(diagnostic.range.start.line).text;

  // Get surrounding context (5 lines before and after)
  const startLine = Math.max(0, diagnostic.range.start.line - 5);
  const endLine = Math.min(document.lineCount - 1, diagnostic.range.start.line + 5);
  const contextLines: string[] = [];
  for (let i = startLine; i <= endLine; i++) {
    contextLines.push(document.lineAt(i).text);
  }
  const surroundingContext = contextLines.join('\n');

  const issue = {
    message: diagnostic.message,
    rule: diagnostic.code as string,
    severity: 'warning' as const,
    line: diagnostic.range.start.line,
    column: diagnostic.range.start.character,
    snippet: lineText,
  };

  await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: 'A11y Scanner: Generating AI fix...',
      cancellable: false,
    },
    async () => {
      const fix = await getAiFix(lineText, issue, surroundingContext);
      if (!fix) {
        return;
      }

      const edit = new vscode.WorkspaceEdit();
      edit.replace(uri, diagnostic.range, fix.fixedCode);
      await vscode.workspace.applyEdit(edit);

      vscode.window.showInformationMessage(`A11y Fix Applied: ${fix.explanation}`);
    },
  );
}

/**
 * Extracts the rule string from a diagnostic's code, which may be a string,
 * number, or { value, target } object.
 */
function extractRuleCode(diagnostic: vscode.Diagnostic): string | undefined {
  const code = diagnostic.code;
  if (typeof code === 'string') { return code; }
  if (typeof code === 'number') { return String(code); }
  if (code && typeof code === 'object' && 'value' in code) {
    return String(code.value);
  }
  return undefined;
}

/**
 * Command handler: previews all static fixes for a specific rule (or all rules) in a file.
 * Shows a BulkFixPreviewPanel so the user can accept/reject individual changes.
 * When called without arguments (e.g. from the command palette), prompts the user to pick a rule.
 */
export async function bulkFixRuleCommand(uri?: vscode.Uri, ruleId?: string): Promise<void> {
  // Resolve URI from active editor if not provided
  if (!uri) {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showWarningMessage('A11y Scanner: No active file to bulk fix.');
      return;
    }
    uri = editor.document.uri;
  }

  const document = await vscode.workspace.openTextDocument(uri);

  // Scan the file directly so we always have fresh diagnostics
  const diagnostics = await scanFileToDiagnostics(document);

  // If no ruleId, fix all rules in the file — skip the picker and go straight to preview
  if (!ruleId) {
    const hasFixable = diagnostics.some(d => {
      const rule = extractRuleCode(d);
      return rule && getStaticFixAttribute(rule, d) !== null;
    });

    if (!hasFixable) {
      vscode.window.showInformationMessage('A11y Scanner: No auto-fixable issues in this file.');
      return;
    }
  }

  const entry = buildChangesForFile(document, uri, diagnostics, ruleId);

  if (!entry || entry.changes.length === 0) {
    const label = ruleId ? `"${ruleId}"` : 'auto-fixable';
    vscode.window.showInformationMessage(`A11y Scanner: No ${label} issues found.`);
    return;
  }

  BulkFixPreviewPanel.createOrShow({ files: [entry] });
}

/**
 * Command handler: scans all workspace files and previews all static bulk fixes
 * across the entire repository. Uses the AST scanner directly so every file is
 * analyzed, not just files that happen to be open.
 */
export async function bulkFixWorkspaceCommand(): Promise<void> {
  const fileUris = await vscode.workspace.findFiles('**/*.{tsx,jsx}', '**/node_modules/**');

  if (fileUris.length === 0) {
    vscode.window.showInformationMessage('A11y Scanner: No TSX/JSX files found in workspace.');
    return;
  }

  const config = await loadConfig();
  const entries: BulkFixFileEntry[] = [];

  await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: 'A11y Scanner: Scanning workspace for bulk fixes…',
      cancellable: true,
    },
    async (progress, token) => {
      const total = fileUris.length;

      for (let i = 0; i < total; i++) {
        if (token.isCancellationRequested) { break; }

        const fileUri = fileUris[i];

        if (isExcluded(config, fileUri.fsPath)) { continue; }

        progress.report({
          increment: (1 / total) * 100,
          message: `(${i + 1}/${total}) ${vscode.workspace.asRelativePath(fileUri)}`,
        });

        const document = await vscode.workspace.openTextDocument(fileUri);

        // Scan with the AST scanner directly — no dependency on open editors
        const diagnostics = await scanFileToDiagnostics(document);

        if (diagnostics.length === 0) { continue; }

        const entry = buildChangesForFile(document, fileUri, diagnostics);
        if (entry && entry.changes.length > 0) {
          entries.push(entry);
        }
      }
    },
  );

  if (entries.length === 0) {
    vscode.window.showInformationMessage('A11y Scanner: No auto-fixable issues found across the workspace.');
    return;
  }

  const totalChanges = entries.reduce((sum, e) => sum + e.changes.length, 0);
  BulkFixPreviewPanel.createOrShow({ files: entries });
  vscode.window.showInformationMessage(
    `A11y Scanner: Found ${totalChanges} fixable issue(s) across ${entries.length} file(s).`,
  );
}

/**
 * Scan a document using the AST scanner and return VS Code Diagnostics.
 * This works regardless of whether the file has been opened or scanned before.
 */
async function scanFileToDiagnostics(document: vscode.TextDocument): Promise<vscode.Diagnostic[]> {
  const config = await loadConfig();
  let issues = scanForA11yIssues(document.getText(), document.fileName);
  issues = applyConfig(config, issues);

  return issues.map(issue => {
    const startPos = new vscode.Position(issue.line, issue.column);
    const endPos = issue.endLine !== undefined && issue.endColumn !== undefined
      ? new vscode.Position(issue.endLine, issue.endColumn)
      : document.lineAt(issue.line).range.end;
    const range = new vscode.Range(startPos, endPos);
    const diagnostic = new vscode.Diagnostic(range, issue.message, toVscodeSeverity(issue.severity));
    diagnostic.source = 'A11y Scanner';
    diagnostic.code = issue.rule;
    return diagnostic;
  });
}

/**
 * Builds preview changes for a single file from its diagnostics.
 * If ruleId is provided, only fixes for that rule are generated.
 */
function buildChangesForFile(
  document: vscode.TextDocument,
  uri: vscode.Uri,
  diagnostics: vscode.Diagnostic[],
  ruleId?: string,
): BulkFixFileEntry | null {
  const filtered = ruleId
    ? diagnostics.filter(d => extractRuleCode(d) === ruleId)
    : diagnostics.filter(d => {
        const rule = extractRuleCode(d);
        if (!rule) { return false; }
        if (getStaticFixAttribute(rule, d) !== null) { return true; }
        const lineText = document.lineAt(d.range.start.line).text;
        return getStaticFixReplacement(rule, d, lineText) !== null;
      });

  if (filtered.length === 0) { return null; }

  const changes: A11yChange[] = [];
  let nextId = 1;

  for (const diagnostic of filtered) {
    const rule = extractRuleCode(diagnostic);
    if (!rule) { continue; }

    const lineNum = diagnostic.range.start.line;
    const lineText = document.lineAt(lineNum).text;

    // Try attribute insertion first
    const attribute = getStaticFixAttribute(rule, diagnostic);
    if (attribute) {
      const tagStart = diagnostic.range.start.character;
      const insertIndex = findOpeningTagClose(lineText, tagStart);

      if (insertIndex !== -1) {
        changes.push({
          id: nextId++,
          startLine: lineNum + 1,
          endLine: lineNum + 1,
          original: lineText,
          replacement: lineText.substring(0, insertIndex) + ` ${attribute} ` + lineText.substring(insertIndex),
          explanation: `Add \`${attribute}\` to fix ${rule}`,
          rule,
        });
      }
      continue;
    }

    // Try full line replacement (heading-order, aria-role, color-contrast)
    const lineReplacement = getStaticFixReplacement(rule, diagnostic, lineText);
    if (lineReplacement) {
      changes.push({
        id: nextId++,
        startLine: lineNum + 1,
        endLine: lineNum + 1,
        original: lineText,
        replacement: lineReplacement.replacement,
        explanation: lineReplacement.explanation,
        rule,
      });
    }
  }

  if (changes.length === 0) { return null; }

  return {
    uri,
    relativePath: vscode.workspace.asRelativePath(uri),
    changes,
  };
}

/**
 * Returns the attribute string to insert for a given rule, or null if no static fix exists.
 */
function getStaticFixAttribute(ruleId: string, diagnostic: vscode.Diagnostic): string | null {
  switch (ruleId) {
    case 'img-alt':
      return 'alt=""';
    case 'button-label':
      return 'aria-label=""';
    case 'form-label':
      return 'aria-label=""';
    case 'click-events-have-key-events':
      return 'role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { /* handler */ } }}';
    case 'nextjs-image-alt':
      return 'alt=""';
    case 'nextjs-head-lang':
      return 'lang="en"';
    case 'nextjs-link-text':
      return 'aria-label=""';
    case 'autocomplete-valid':
      return 'autoComplete="name"';
    case 'no-mouse-only-hover':
      return 'onFocus={() => {}}';
    case 'aria-pattern': {
      const msg = diagnostic.message;
      if (msg.includes('aria-labelledby') || msg.includes('aria-label')) {
        return 'aria-label=""';
      }
      if (msg.includes('aria-expanded')) {
        return 'aria-expanded={false}';
      }
      if (msg.includes('aria-controls') || msg.includes('aria-selected')) {
        return 'aria-controls="" aria-selected={false}';
      }
      return null;
    }
    default:
      return null;
  }
}

/**
 * Returns a full line replacement for rules that need more than attribute insertion.
 * Used by buildChangesForFile when getStaticFixAttribute returns null.
 */
function getStaticFixReplacement(
  ruleId: string,
  diagnostic: vscode.Diagnostic,
  lineText: string,
): { replacement: string; explanation: string } | null {
  switch (ruleId) {
    case 'heading-order': {
      const msg = diagnostic.message;
      const currentTagMatch = msg.match(/<(h[1-6])>/);
      let currentTag: string | null = null;
      let targetTag: string | null = null;

      if (currentTagMatch && msg.includes('skipped')) {
        const prevMatch = msg.match(/follows `<h(\d)>/);
        if (prevMatch) {
          const suggested = parseInt(prevMatch[1], 10) + 1;
          if (suggested <= 6) {
            currentTag = currentTagMatch[1];
            targetTag = `h${suggested}`;
          }
        }
      } else if (msg.includes('Multiple') && msg.includes('<h1>')) {
        currentTag = 'h1';
        targetTag = 'h2';
      } else if (msg.includes('First heading') && currentTagMatch) {
        currentTag = currentTagMatch[1];
        targetTag = 'h1';
      }

      if (currentTag && targetTag) {
        let replacement = lineText;
        // Replace opening tag (e.g. <h4 or <h4>)
        replacement = replacement.replace(
          new RegExp(`<${escapeRegExp(currentTag)}(\\s|>|/>)`),
          `<${targetTag}$1`,
        );
        // Replace closing tag
        replacement = replacement.replace(
          new RegExp(`</${escapeRegExp(currentTag)}>`),
          `</${targetTag}>`,
        );
        if (replacement !== lineText) {
          return { replacement, explanation: `Change <${currentTag}> to <${targetTag}>` };
        }
      }
      return null;
    }

    case 'aria-role': {
      const roleMatch = diagnostic.message.match(/Invalid ARIA role "([^"]+)"/);
      if (roleMatch) {
        const invalidRole = roleMatch[1];
        const closest = findClosestRole(invalidRole);
        if (closest) {
          const replacement = lineText.replace(`"${invalidRole}"`, `"${closest}"`);
          if (replacement !== lineText) {
            return { replacement, explanation: `Replace invalid role "${invalidRole}" with "${closest}"` };
          }
        }
      }
      return null;
    }

    case 'color-contrast': {
      const fgMatch = diagnostic.message.match(/foreground: "([^"]+)"/);
      const bgMatch = diagnostic.message.match(/background: "([^"]+)"/);
      if (fgMatch && bgMatch) {
        const fixedFg = suggestAccessibleForeground(fgMatch[1], bgMatch[1]);
        if (fixedFg) {
          const colorPattern = new RegExp(
            `(color:\\s*["'])${escapeRegExp(fgMatch[1])}(["'])`, 'i',
          );
          const replacement = lineText.replace(colorPattern, `$1${fixedFg}$2`);
          if (replacement !== lineText) {
            return { replacement, explanation: `Adjust foreground color to "${fixedFg}" for sufficient contrast` };
          }
        }
      }
      return null;
    }

    default:
      return null;
  }
}
