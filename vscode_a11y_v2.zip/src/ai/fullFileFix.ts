import * as vscode from 'vscode';
import { scanForA11yIssues } from '../scanner/astScanner';

/** A single atomic change the AI proposes. */
export interface A11yChange {
  id: number;
  /** 1-based line number where the change starts. */
  startLine: number;
  /** 1-based line number where the change ends (inclusive). */
  endLine: number;
  /** The original code snippet. */
  original: string;
  /** The proposed replacement. */
  replacement: string;
  /** Human-readable explanation of the fix. */
  explanation: string;
  /** The a11y rule that triggered this change. */
  rule: string;
}

export interface FullFileFixResult {
  changes: A11yChange[];
  designSystemDetected: string | null;
}

/**
 * Detect the design system / component library used in the project by
 * inspecting package.json dependencies.
 */
async function detectDesignSystem(): Promise<string | null> {
  const knownSystems: Record<string, string> = {
    '@mui/material': 'Material UI (MUI)',
    '@chakra-ui/react': 'Chakra UI',
    'antd': 'Ant Design',
    '@fluentui/react': 'Fluent UI',
    '@fluentui/react-components': 'Fluent UI v9',
    'react-bootstrap': 'React Bootstrap',
    '@radix-ui/react-primitive': 'Radix UI',
    '@headlessui/react': 'Headless UI',
    'semantic-ui-react': 'Semantic UI React',
    '@mantine/core': 'Mantine',
  };

  const pkgFiles = await vscode.workspace.findFiles('package.json', '**/node_modules/**', 1);
  if (pkgFiles.length === 0) { return null; }

  try {
    const raw = await vscode.workspace.fs.readFile(pkgFiles[0]);
    const pkg = JSON.parse(Buffer.from(raw).toString('utf-8'));
    const deps = { ...pkg.dependencies, ...pkg.devDependencies };

    for (const [key, label] of Object.entries(knownSystems)) {
      if (deps[key]) { return label; }
    }
  } catch {
    // Ignore parse errors
  }
  return null;
}

/**
 * Gather codebase context: imports in sibling files, shared component
 * patterns, etc. Returns a summary string for the AI prompt.
 */
async function gatherCodebaseContext(document: vscode.TextDocument): Promise<string> {
  const parts: string[] = [];

  // 1. Collect imports from the current file to understand patterns in use.
  const text = document.getText();
  const importLines = text.split('\n').filter(l => /^\s*import\s/.test(l));
  if (importLines.length > 0) {
    parts.push('Current file imports:\n' + importLines.join('\n'));
  }

  // 2. Sample component patterns from up to 3 sibling files in the same dir.
  const dir = vscode.Uri.joinPath(document.uri, '..');
  const pattern = new vscode.RelativePattern(dir, '*.{tsx,jsx}');
  const siblings = await vscode.workspace.findFiles(pattern, '**/node_modules/**', 4);

  for (const sibUri of siblings) {
    if (sibUri.toString() === document.uri.toString()) { continue; }
    if (parts.length > 800) { break; }
    try {
      const sibDoc = await vscode.workspace.openTextDocument(sibUri);
      const sibImports = sibDoc.getText().split('\n').filter(l => /^\s*import\s/.test(l));
      if (sibImports.length > 0) {
        parts.push(`Sibling ${vscode.workspace.asRelativePath(sibUri)} imports:\n` + sibImports.join('\n'));
      }
    } catch { /* skip */ }
  }

  return parts.join('\n\n');
}

const FULL_FILE_SYSTEM_PROMPT = `You are an accessibility expert specializing in React and WCAG 2.1 Level AA compliance.
You will receive:
- The full source code of a file with line numbers prefixed (e.g. "  1| import React...")
- A list of detected accessibility issues with line numbers
- Information about the design system and codebase patterns in use

Your task: produce a JSON object with a key "changes" containing an array of **individual, independent changes** that fix ALL accessibility issues.

The response must be:
{
  "changes": [
    {
      "startLine": <1-based first line of original snippet>,
      "endLine": <1-based last line of original snippet (inclusive)>,
      "original": "<EXACT copy of the source lines being replaced, including all whitespace>",
      "replacement": "<fixed code with same indentation>",
      "explanation": "<brief explanation>",
      "rule": "<the a11y rule id>"
    }
  ]
}

CRITICAL RULES:
- You MUST produce exactly ONE change per issue listed. Every issue MUST have a corresponding fix.
- The "original" field MUST be a character-for-character exact copy of the lines from the source code (without the line number prefix). If it does not match exactly, the change will be rejected.
- Each change should target the SMALLEST possible range — ideally a SINGLE LINE. Only include multiple lines if the JSX element spans multiple lines.
- Each change must be independent and NOT overlap with any other change's line range. Two changes must never share the same line numbers.
- Do NOT change any logic, variable names, function signatures, imports, or non-JSX code.
- Do NOT merge multiple fixes into one change even if they are on adjacent lines. Even if two issues are on the same line, produce TWO separate changes.
- The "replacement" must have the EXACT same indentation (spaces/tabs) as the "original".
- The replacement must keep ALL original attributes and only ADD or MODIFY the accessibility-related attribute.
- NEVER add new HTML/JSX elements. NEVER remove existing elements or text content. ONLY modify existing elements by adding/changing attributes or roles.
- For ARIA pattern issues (e.g. "tablist must contain tab children"): add the missing role to the EXISTING child element, do NOT insert a new element. For example, if a tablist contains \`<div>Item</div>\`, change IT to \`<div role="tab" aria-controls="panel-id" aria-selected="false">Item</div>\` — do NOT add a second element.
- IMPORTANT: Be aware of cascading ARIA requirements. When you add a role, also add ALL required attributes for that role in the SAME change:
  * role="tab" also needs aria-controls and aria-selected
  * role="tabpanel" also needs aria-labelledby
  * role="dialog" also needs aria-labelledby or aria-label
  * role="combobox" also needs aria-expanded
- For heading-order fixes: plan ALL heading level changes together so the final sequence is valid (h1 → h2 → h3, no skips). Do NOT just fix one heading if it would leave others still out of order.
- For parent-child ARIA issues, the change must target the CHILD element that needs the role, not the parent.
- Preserve existing functionality, styling, and the design system conventions used in the codebase.
- Use semantic HTML where possible.
- If the project uses a specific component library, use its accessible component APIs.
- Return ONLY the JSON object, no markdown fences, no extra text.`;

/**
 * Request a full-file accessibility fix from the configured AI provider.
 * Performs up to 2 passes to catch cascading issues (e.g. adding role="tab"
 * triggers a secondary rule requiring aria-controls).
 */
export async function getFullFileFix(document: vscode.TextDocument): Promise<FullFileFixResult | null> {
  const config = vscode.workspace.getConfiguration('a11y');
  const provider = config.get<string>('aiProvider', 'none');

  if (provider === 'none') {
    vscode.window.showWarningMessage('A11y Scanner: AI provider is set to "none". Configure an AI provider in settings.');
    return null;
  }

  const sourceCode = document.getText();
  const fileName = document.fileName;

  // 1. Scan for issues
  const issues = scanForA11yIssues(sourceCode, fileName);
  if (issues.length === 0) {
    vscode.window.showInformationMessage('A11y Scanner: No accessibility issues found in this file.');
    return null;
  }

  // 2. Detect design system & gather context
  const [designSystem, codebaseContext] = await Promise.all([
    detectDesignSystem(),
    gatherCodebaseContext(document),
  ]);

  const apiKey = await getApiKey(config);
  if (!apiKey) { return null; }
  const model = config.get<string>('aiModel', 'gpt-4');

  // ── Pass 1: fix all detected issues ──
  const pass1Changes = await fetchAndValidateChanges(
    sourceCode, fileName, issues, designSystem, codebaseContext,
    apiKey, model, provider, config,
  );

  if (!pass1Changes || pass1Changes.length === 0) {
    return null;
  }

  // ── Simulate applying pass 1 & re-scan for cascading issues ──
  const simulatedSource = simulateApply(sourceCode, pass1Changes);
  const remainingIssues = scanForA11yIssues(simulatedSource, fileName);

  let allChanges = [...pass1Changes];

  if (remainingIssues.length > 0) {
    // ── Pass 2: fix cascading issues on the simulated source ──
    const pass2Changes = await fetchAndValidateChanges(
      simulatedSource, fileName, remainingIssues, designSystem, codebaseContext,
      apiKey, model, provider, config,
    );

    if (pass2Changes && pass2Changes.length > 0) {
      // Remap pass 2 changes back to the ORIGINAL source by merging them into pass 1
      allChanges = mergePassChanges(sourceCode, pass1Changes, pass2Changes, simulatedSource);
    }
  }

  // Re-number IDs
  allChanges.forEach((c, i) => { c.id = i + 1; });

  return { changes: allChanges, designSystemDetected: designSystem };
}

/**
 * Call the AI, parse, and validate the response. Returns validated changes or null.
 */
async function fetchAndValidateChanges(
  sourceCode: string,
  _fileName: string,
  issues: ReturnType<typeof scanForA11yIssues>,
  designSystem: string | null,
  codebaseContext: string,
  apiKey: string,
  model: string,
  provider: string,
  config: vscode.WorkspaceConfiguration,
): Promise<A11yChange[] | null> {
  const issueList = issues.map((issue, idx) =>
    `${idx + 1}. [Line ${issue.line + 1}] (${issue.rule}) ${issue.message}`
  ).join('\n');

  const userMessage = buildUserMessage(sourceCode, issueList, designSystem, codebaseContext);

  let rawResponse: string;
  try {
    rawResponse = provider === 'azure-openai'
      ? await callAzure(apiKey, model, userMessage, config)
      : await callOpenAI(apiKey, model, userMessage);
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Unknown error';
    vscode.window.showErrorMessage(`A11y Scanner: AI request failed — ${msg}`);
    return null;
  }

  return parseAndValidate(rawResponse, sourceCode);
}

/**
 * Parse the AI response and validate each change against the source.
 */
function parseAndValidate(rawResponse: string, sourceCode: string): A11yChange[] | null {
  try {
    let cleaned = rawResponse.trim();
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');

    const parsed = JSON.parse(cleaned);
    const arr: any[] = Array.isArray(parsed) ? parsed : (parsed.changes ?? parsed.fixes ?? []);

    if (!Array.isArray(arr) || arr.length === 0) {
      return null;
    }

    const sourceLines = sourceCode.split('\n');
    const validatedChanges: A11yChange[] = [];

    for (let idx = 0; idx < arr.length; idx++) {
      const c = arr[idx];
      const change: A11yChange = {
        id: idx + 1,
        startLine: c.startLine,
        endLine: c.endLine,
        original: c.original,
        replacement: c.replacement,
        explanation: c.explanation,
        rule: c.rule,
      };

      // Safety: reject changes that add new JSX elements (opening tags)
      const origTagCount = (change.original.match(/<[A-Za-z]/g) || []).length;
      const replTagCount = (change.replacement.match(/<[A-Za-z]/g) || []).length;
      if (replTagCount > origTagCount + 1) {
        continue;
      }

      // Safety: reject if replacement removes significant content
      const origTextLen = change.original.replace(/<[^>]*>/g, '').replace(/\s+/g, '').length;
      const replTextLen = change.replacement.replace(/<[^>]*>/g, '').replace(/\s+/g, '').length;
      if (origTextLen > 0 && replTextLen < origTextLen * 0.5) {
        continue;
      }

      // Validate: original must match the actual source lines
      const actualLines = sourceLines.slice(change.startLine - 1, change.endLine);
      const actualText = actualLines.join('\n');

      if (change.original.trim() === actualText.trim()) {
        change.original = actualText;
        validatedChanges.push(change);
      } else {
        const found = fuzzyFindOriginal(sourceLines, change.original, change.startLine);
        if (found) {
          change.startLine = found.startLine;
          change.endLine = found.endLine;
          change.original = found.text;
          validatedChanges.push(change);
        }
      }
    }

    return removeOverlaps(validatedChanges);
  } catch {
    return null;
  }
}

/**
 * Simulate applying changes to get the resulting source code.
 */
function simulateApply(sourceCode: string, changes: A11yChange[]): string {
  const lines = sourceCode.split('\n');
  // Apply bottom-up to preserve line numbers
  const sorted = [...changes].sort((a, b) => b.startLine - a.startLine);

  for (const change of sorted) {
    const start = change.startLine - 1;
    const end = change.endLine; // endLine is 1-based inclusive, so slice end = endLine
    const replacementLines = change.replacement.split('\n');
    lines.splice(start, end - start, ...replacementLines);
  }

  return lines.join('\n');
}

/**
 * Merge pass 2 changes (which were computed against the simulated source)
 * back into the pass 1 change list. For each pass 2 change, if it targets a
 * line range that was already modified by pass 1, we update that pass 1 change's
 * replacement. Otherwise we add it directly (adjusting line numbers).
 */
function mergePassChanges(
  _originalSource: string,
  pass1: A11yChange[],
  pass2: A11yChange[],
  _simulatedSource: string,
): A11yChange[] {
  const merged = [...pass1];

  for (const p2 of pass2) {
    // Check if this pass2 change falls within a pass1 change's replacement
    let mergedInto = false;

    for (const p1 of merged) {
      // Calculate where pass1's replacement sits in the simulated source
      const p1ReplacementLineCount = p1.replacement.split('\n').length;
      // pass1 replaced lines startLine..endLine with replacement
      // In simulated source, the replacement occupies startLine..(startLine + repLineCount - 1)
      const simStart = p1.startLine;
      const simEnd = p1.startLine + p1ReplacementLineCount - 1;

      if (p2.startLine >= simStart && p2.endLine <= simEnd) {
        // pass2 targets within pass1's replacement — update pass1's replacement
        const p1RepLines = p1.replacement.split('\n');
        const localStart = p2.startLine - simStart;
        const localEnd = p2.endLine - simStart;
        const p2RepLines = p2.replacement.split('\n');
        p1RepLines.splice(localStart, localEnd - localStart + 1, ...p2RepLines);
        p1.replacement = p1RepLines.join('\n');
        p1.explanation += ` + ${p2.explanation}`;
        mergedInto = true;
        break;
      }
    }

    if (!mergedInto) {
      // This pass2 change targets a line that wasn't modified by pass1 —
      // we need to map its line number back to the original source
      const originalLine = mapSimLineToOriginal(pass1, p2.startLine);
      const originalEndLine = mapSimLineToOriginal(pass1, p2.endLine);
      if (originalLine !== null && originalEndLine !== null) {
        // Fetch the original text at those lines
        const origLines = _originalSource.split('\n');
        const origText = origLines.slice(originalLine - 1, originalEndLine).join('\n');
        merged.push({
          ...p2,
          startLine: originalLine,
          endLine: originalEndLine,
          original: origText,
        });
      }
    }
  }

  return removeOverlaps(merged.sort((a, b) => a.startLine - b.startLine));
}

/**
 * Map a line number from the simulated source back to the original source,
 * accounting for line count changes from pass 1.
 */
function mapSimLineToOriginal(pass1Changes: A11yChange[], simLine: number): number | null {
  // Sort pass1 changes by startLine
  const sorted = [...pass1Changes].sort((a, b) => a.startLine - b.startLine);
  let offset = 0;

  for (const c of sorted) {
    const origLineCount = c.endLine - c.startLine + 1;
    const replLineCount = c.replacement.split('\n').length;
    const simStart = c.startLine + offset;
    const simEnd = simStart + replLineCount - 1;

    if (simLine >= simStart && simLine <= simEnd) {
      // Inside a changed region — can't map precisely
      return null;
    }

    if (simLine > simEnd) {
      offset += replLineCount - origLineCount;
    }
  }

  return simLine - offset;
}

/**
 * Try to find the `original` text near the expected startLine (within ±5 lines).
 */
function fuzzyFindOriginal(
  sourceLines: string[],
  original: string,
  expectedStart: number,
): { startLine: number; endLine: number; text: string } | null {
  const origTrimmed = original.trim();
  const origLineCount = original.split('\n').length;
  const searchRadius = 5;

  for (let offset = 0; offset <= searchRadius; offset++) {
    for (const dir of [0, -1, 1]) {
      const start = expectedStart - 1 + (offset * (dir || 1)); // 0-based
      if (start < 0 || start + origLineCount > sourceLines.length) { continue; }
      const candidate = sourceLines.slice(start, start + origLineCount).join('\n');
      if (candidate.trim() === origTrimmed) {
        return {
          startLine: start + 1,
          endLine: start + origLineCount,
          text: candidate,
        };
      }
    }
  }
  return null;
}

/**
 * Remove strictly overlapping changes — two changes conflict only if their
 * ranges actually overlap (not just touch). When they overlap, try to merge;
 * if that's not possible, keep the first.
 */
function removeOverlaps(changes: A11yChange[]): A11yChange[] {
  const sorted = [...changes].sort((a, b) => a.startLine - b.startLine || a.endLine - b.endLine);
  const result: A11yChange[] = [];

  for (const change of sorted) {
    const prev = result[result.length - 1];
    if (!prev || change.startLine > prev.endLine) {
      // No overlap — add directly
      result.push(change);
    } else if (change.startLine === prev.startLine && change.endLine === prev.endLine) {
      // Same range — merge: apply both replacements by using the second
      // (it's likely a more complete fix on the same element)
      result[result.length - 1] = change;
    }
    // True overlap with different ranges — drop the later one (can't safely merge)
  }
  return result;
}

/* ── Helpers ────────────────────────────────────────────── */

function buildUserMessage(
  sourceCode: string,
  issueList: string,
  designSystem: string | null,
  codebaseContext: string,
): string {
  // Add line numbers to help AI reference exact lines
  const numberedSource = sourceCode.split('\n')
    .map((line, i) => `${String(i + 1).padStart(4)}| ${line}`)
    .join('\n');

  let msg = `## Full Source Code (with line numbers)\n\`\`\`tsx\n${numberedSource}\n\`\`\`\n\n`;
  msg += `## Detected Accessibility Issues\n${issueList}\n\n`;
  msg += `IMPORTANT: The "original" field in each change must be the EXACT text from the source (WITHOUT the line number prefix). Copy it character-for-character.\n\n`;
  if (designSystem) {
    msg += `## Design System\nThis project uses **${designSystem}**. Ensure fixes follow its component APIs and conventions.\n\n`;
  }
  if (codebaseContext) {
    msg += `## Codebase Context\n${codebaseContext}\n`;
  }
  return msg;
}

async function getApiKey(config: vscode.WorkspaceConfiguration): Promise<string | null> {
  // Use vscode.commands to get the secrets — provider.ts stores them
  // We import lazily to avoid circular deps.
  const { getStoredApiKey } = await import('./provider');
  const key = await getStoredApiKey();
  if (key) { return key; }

  const legacyKey = config.get<string>('aiApiKey', '');
  if (legacyKey) {
    vscode.window.showWarningMessage(
      'A11y Scanner: API key found in plaintext settings. Run "A11y: Set AI API Key" to store it securely, then remove a11y.aiApiKey from settings.',
    );
    return legacyKey;
  }

  vscode.window.showWarningMessage('A11y Scanner: AI API key not configured. Run "A11y: Set AI API Key".');
  return null;
}

const AI_TIMEOUT_MS = 60_000; // full-file fixes need more time

async function callOpenAI(apiKey: string, model: string, userMessage: string): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: FULL_FILE_SYSTEM_PROMPT },
          { role: 'user', content: userMessage },
        ],
        temperature: 0.2,
        response_format: { type: 'json_object' },
      }),
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }
    const data = await response.json() as any;
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== 'string') {
      throw new Error('Unexpected AI response format: no content returned');
    }
    return content;
  } catch (e: unknown) {
    if (e instanceof DOMException && e.name === 'AbortError') {
      throw new Error('AI request timed out. The file may be too large — try reducing its size or increasing the timeout.');
    }
    throw e;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function callAzure(
  apiKey: string,
  deployment: string,
  userMessage: string,
  config: vscode.WorkspaceConfiguration,
): Promise<string> {
  const endpoint = config.get<string>('aiEndpoint', '');
  if (!endpoint) { throw new Error('Azure OpenAI endpoint not configured'); }

  const url = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=2024-02-01`;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': apiKey,
      },
      body: JSON.stringify({
        messages: [
          { role: 'system', content: FULL_FILE_SYSTEM_PROMPT },
          { role: 'user', content: userMessage },
        ],
        temperature: 0.2,
        response_format: { type: 'json_object' },
      }),
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new Error(`Azure OpenAI API error: ${response.status} ${response.statusText}`);
    }
    const data = await response.json() as any;
    const content = data?.choices?.[0]?.message?.content;
    if (typeof content !== 'string') {
      throw new Error('Unexpected AI response format: no content returned');
    }
    return content;
  } catch (e: unknown) {
    if (e instanceof DOMException && e.name === 'AbortError') {
      throw new Error('AI request timed out. The file may be too large — try reducing its size or increasing the timeout.');
    }
    throw e;
  } finally {
    clearTimeout(timeoutId);
  }
}
