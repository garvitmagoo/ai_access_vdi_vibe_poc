import * as vscode from 'vscode';

let statusBarItem: vscode.StatusBarItem;
let lastUri: string | undefined;
let lastScore: number | undefined;
let lastCount: number | undefined;

export function createStatusBarItem(context: vscode.ExtensionContext): vscode.StatusBarItem {
  statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  statusBarItem.command = 'a11y.showReport';
  statusBarItem.tooltip = 'Accessibility score for current file — click to view report';
  context.subscriptions.push(statusBarItem);
  statusBarItem.show();
  updateStatusBarScore();
  return statusBarItem;
}

export function updateStatusBarScore(): void {
  if (!statusBarItem) {
    return;
  }

  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    // Keep the last displayed score when switching to a non-editor tab
    // (e.g. webview panels like Screen Reader Preview)
    return;
  }

  const diagnostics = vscode.languages.getDiagnostics(editor.document.uri)
    .filter(d => d.source === 'A11y Scanner');

  const currentUri = editor.document.uri.toString();
  const score = computeScore(diagnostics);
  const count = diagnostics.length;

  // Skip update if nothing changed
  if (currentUri === lastUri && score === lastScore && count === lastCount) {
    return;
  }
  lastUri = currentUri;
  lastScore = score;
  lastCount = count;

  // Build severity breakdown for tooltip
  const errors = diagnostics.filter(d => d.severity === vscode.DiagnosticSeverity.Error).length;
  const warnings = diagnostics.filter(d => d.severity === vscode.DiagnosticSeverity.Warning).length;
  const infos = diagnostics.filter(d => d.severity === vscode.DiagnosticSeverity.Information).length;
  const hints = diagnostics.filter(d => d.severity === vscode.DiagnosticSeverity.Hint).length;

  const breakdownParts: string[] = [];
  if (errors > 0) { breakdownParts.push(`${errors} error(s)`); }
  if (warnings > 0) { breakdownParts.push(`${warnings} warning(s)`); }
  if (infos > 0) { breakdownParts.push(`${infos} info`); }
  if (hints > 0) { breakdownParts.push(`${hints} hint(s)`); }
  const breakdown = breakdownParts.join(', ');

  if (diagnostics.length === 0) {
    statusBarItem.text = `$(check) A11y: ${score}/100`;
    statusBarItem.backgroundColor = undefined;
    statusBarItem.tooltip = 'No accessibility issues found!';
  } else if (score >= 80) {
    statusBarItem.text = `$(check) A11y: ${score}/100`;
    statusBarItem.backgroundColor = undefined;
    statusBarItem.tooltip = `${breakdown} — good accessibility`;
  } else if (score >= 50) {
    statusBarItem.text = `$(warning) A11y: ${score}/100`;
    statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    statusBarItem.tooltip = `${breakdown} — needs improvement`;
  } else {
    statusBarItem.text = `$(error) A11y: ${score}/100`;
    statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
    statusBarItem.tooltip = `${breakdown} — poor accessibility`;
  }
}

function computeScore(diagnostics: vscode.Diagnostic[]): number {
  let penalty = 0;

  for (const d of diagnostics) {
    switch (d.severity) {
      case vscode.DiagnosticSeverity.Error:
        penalty += 10;
        break;
      case vscode.DiagnosticSeverity.Warning:
        penalty += 5;
        break;
      case vscode.DiagnosticSeverity.Information:
        penalty += 2;
        break;
      case vscode.DiagnosticSeverity.Hint:
        penalty += 1;
        break;
    }
  }

  return Math.max(0, 100 - penalty);
}
