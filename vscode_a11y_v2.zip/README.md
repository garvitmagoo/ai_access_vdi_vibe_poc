# A11y Scanner — VS Code Extension

AI-powered accessibility scanner for React/JSX/TSX projects. Detects WCAG 2.1 Level AA violations inline, previews screen reader output, generates accessibility tests, and provides intelligent fix suggestions.

## Features

- **Real-time scanning** — Detects accessibility issues as you type with debounced diagnostics
- **16 built-in rules** — Covers WCAG 2.1 Level AA success criteria (see [Rules](#rules))
- **Inline diagnostics** — Issues appear as squiggly underlines in the editor
- **Quick Fixes** — Click the lightbulb to apply fixes instantly
- **Bulk Fix** — Fix all issues of a rule in a file, or across the entire workspace, with a preview panel
- **AI-powered fixes** — Optional OpenAI / Azure OpenAI integration for context-aware fix suggestions
- **AI Fix Entire File** — Let AI fix all issues in a file at once with a diff preview
- **Screen Reader Preview** — Simulates how a screen reader would announce elements in your file
- **Accessibility Score** — Live score (0–100) in the status bar with severity breakdown
- **Git Regression Tracking** — Compare issues between your working tree and the last commit
- **Test Generation** — Auto-generate accessibility test cases from detected issues
- **CI/CD Export** — Export SARIF (for GitHub Code Scanning) or JSON reports
- **Configurable** — Enable/disable rules, set severity overrides, and exclude files via `.a11yrc.json`

## Rules

| Rule | WCAG | Severity | Description |
|------|------|----------|-------------|
| `img-alt` | 1.1.1 | Error | `<img>` elements must have an `alt` attribute |
| `button-label` | 4.1.2 | Error | Buttons must have accessible names (`aria-label`, text, etc.) |
| `aria-role` | 4.1.2 | Error | ARIA `role` values must be valid WAI-ARIA roles |
| `form-label` | 1.3.1 | Warning | Form inputs must have associated labels |
| `click-events-have-key-events` | 2.1.1 | Warning | Non-interactive elements with `onClick` need keyboard handlers |
| `aria-pattern` | 4.1.2 | Error | ARIA widget patterns must be correctly structured |
| `color-contrast` | 1.4.3 | Warning | Inline styles must meet WCAG AA contrast ratio |
| `heading-order` | 1.3.1 | Warning | Heading levels must follow a logical hierarchy |
| `autocomplete-valid` | 1.3.5 | Warning | Personal data inputs must have valid `autoComplete` |
| `no-positive-tabindex` | 2.4.3 | Warning | Avoid `tabIndex` > 0 (disrupts focus order) |
| `focus-visible` | 2.4.7 | Warning | Don't remove `outline` without a replacement focus style |
| `page-title` | 2.4.2 | Warning | `<Head>` must contain a `<title>` element |
| `no-mouse-only-hover` | 1.4.13 | Warning | Hover content must also be keyboard-accessible |
| `nextjs-head-lang` | 3.1.1 | Error | Next.js `<Html>` must have a `lang` attribute |
| `nextjs-image-alt` | 1.1.1 | Error | Next.js `<Image>` must have an `alt` attribute |
| `nextjs-link-text` | 1.1.1 | Warning | Next.js `<Link>` must have discernible text |

## Getting Started

### Install from Marketplace

Search for **A11y Scanner** in the VS Code Extensions panel, or run:

```bash
code --install-extension lockton.a11y-scanner
```

### Install from VSIX

```bash
code --install-extension a11y-scanner-0.1.0.vsix
```

### Usage

1. Open any `.tsx` or `.jsx` file — issues appear inline automatically
2. Hover over a squiggly underline to see the issue detail
3. Click the lightbulb (or press `Ctrl+.`) to see Quick Fix options
4. Use keyboard shortcuts for fast access (see below)

## Commands

Open the Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`) and type `A11y`:

| Command | Description |
|---------|-------------|
| **A11y: Scan Current File** | Scan the active file for a11y issues |
| **A11y: Scan Workspace** | Scan all TSX/JSX files across the workspace |
| **A11y: Show Accessibility Report** | Open the visual report panel |
| **A11y: Screen Reader Preview** | Simulate screen reader announcements |
| **A11y: Bulk Fix Rule in File** | Preview and apply all fixes for the current file |
| **A11y: Bulk Fix Entire Workspace** | Preview and apply fixes across all files |
| **A11y: AI Fix Entire File** | AI-generated fixes for all issues (requires AI provider) |
| **A11y: Compare with Last Commit** | Show new/fixed issues vs. the last git commit |
| **A11y: Generate Accessibility Tests** | Auto-generate test cases from detected issues |
| **A11y: Export SARIF Report** | Export for CI/CD (GitHub Code Scanning compatible) |
| **A11y: Export JSON Report** | Export as JSON |
| **A11y: Set AI API Key** | Store your API key securely |

## Keyboard Shortcuts

| Shortcut | Command |
|----------|---------|
| `Ctrl+Alt+A` (`Cmd+Alt+A`) | Scan Current File |
| `Ctrl+Alt+R` (`Cmd+Alt+R`) | Show Report |
| `Ctrl+Alt+F` (`Cmd+Alt+F`) | Bulk Fix Rule in File |
| `Ctrl+Alt+Shift+A` (`Cmd+Alt+Shift+A`) | Scan Workspace |

## Configuration

### VS Code Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `a11y.scanOnSave` | `true` | Auto-scan on file save |
| `a11y.scanOnOpen` | `true` | Auto-scan when a file is opened |
| `a11y.severity` | `"warning"` | Default diagnostic severity |
| `a11y.aiProvider` | `"none"` | AI provider: `"none"`, `"openai"`, `"azure-openai"` |
| `a11y.aiEndpoint` | `""` | Azure OpenAI endpoint URL |
| `a11y.aiModel` | `"gpt-4"` | Model/deployment name |

### Enable AI Fixes

1. Run **A11y: Set AI API Key** from the Command Palette to store your key securely
2. Set the provider in VS Code settings:

```json
{
  "a11y.aiProvider": "openai",
  "a11y.aiModel": "gpt-4"
}
```

For Azure OpenAI, also set the endpoint:

```json
{
  "a11y.aiProvider": "azure-openai",
  "a11y.aiEndpoint": "https://your-resource.openai.azure.com",
  "a11y.aiModel": "your-deployment-name"
}
```

### Project-Level Config (`.a11yrc.json`)

Create a `.a11yrc.json` in your workspace root to customize rules and exclusions:

```json
{
  "rules": {
    "color-contrast": { "severity": "error" },
    "heading-order": false
  },
  "exclude": [
    "**/test/**",
    "**/storybook/**"
  ]
}
```

## CI/CD Integration

Export a SARIF report and upload it to GitHub Code Scanning:

```yaml
# .github/workflows/a11y.yml
- name: Upload SARIF
  uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: a11y-report.sarif
```

## Development

```bash
git clone https://github.com/lockton/a11y-scanner-extension.git
cd a11y-scanner-extension
npm install
npm run compile
```

Press `F5` in VS Code to launch the Extension Development Host.

### Run Tests

```bash
npm test
```

### Package

```bash
npm run package
```

## License

[MIT](LICENSE)
