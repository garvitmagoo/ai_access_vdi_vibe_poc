# Changelog

## [0.2.0] - 2026-03-20

### Added

- **5 new WCAG 2.1 rules**: `autocomplete-valid` (1.3.5), `no-positive-tabindex` (2.4.3), `focus-visible` (2.4.7), `page-title` (2.4.2), `no-mouse-only-hover` (1.4.13)
- **Keyboard shortcuts**: `Ctrl+Alt+A` (scan file), `Ctrl+Alt+R` (report), `Ctrl+Alt+F` (bulk fix), `Ctrl+Alt+Shift+A` (scan workspace)
- **Workspace scan progress** with file-by-file progress indicator and cancellation support
- **Detailed skip reporting** for bulk fix — skipped changes logged to Output channel with file, line, and rule
- **Status bar severity breakdown** — tooltip now shows error/warning/info counts

### Improved

- Screen reader preview panel now debounces on text changes (500ms) to prevent typing lag
- Bulk fix in file goes directly to preview panel (no intermediate dropdown)
- Git comparison is now cancellable with 10s timeout per file to prevent hangs

## [0.1.0] - 2025-01-01

### Added

- **AST-based accessibility scanning** for React/JSX/TSX files
- **8 built-in rules**: img-alt, button-label, aria-role, form-label, click-key-events, aria-pattern, color-contrast, heading-order
- **AI-powered fix suggestions** via OpenAI or Azure OpenAI
- **Screen reader text preview** with simulated announcements
- **Accessibility score** in the status bar (0–100)
- **Auto-generate accessibility tests** from detected issues
- **Git regression tracking** — compare accessibility between commits
- **CI/CD export** — SARIF and JSON report formats
- **Real-time scanning** with debounced diagnostics on file change
- **Quick fixes** for every rule via VS Code Code Actions
- **Configuration** support via `.a11yrc.json` (enable/disable rules, exclude files)
- **Secure API key storage** using VS Code SecretStorage
- **Webview report panel** with issue visualization
