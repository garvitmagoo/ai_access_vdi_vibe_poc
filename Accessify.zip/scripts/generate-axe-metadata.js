// Regenerates src/scanner/axeRuleMetadata.json from the installed axe-core.
// We only need rule metadata (impact, WCAG tags, help URLs) for the rules we
// map — not the full axe-core DOM-testing engine — so we extract it at build
// time and keep axe-core as a devDependency only.
//
// Usage: node scripts/generate-axe-metadata.js
const fs = require('fs');
const path = require('path');
const axe = require('axe-core');

// axe-core rule IDs that our scanner rules map to (see RULE_MAP in
// src/scanner/axeIntegration.ts). Keep in sync when adding rule mappings.
const KEEP = new Set([
  'image-alt',
  'button-name',
  'label',
  'aria-allowed-role',
  'aria-required-attr',
  'heading-order',
  'color-contrast',
  'click-events-have-key-events',
  'autocomplete-valid',
  'no-mouse-only-hover',
  'link-name',
  'html-has-lang',
  'no-autofocus',
  'interactive-supports-focus',
  'no-noninteractive-element-interactions',
  'svg-img-alt',
  'aria-allowed-attr',
  'no-autoplay-audio',
  'duplicate-id',
  'aria-valid-attr-value',
]);

const rules = axe
  .getRules()
  .filter((r) => KEEP.has(r.ruleId))
  .map((r) => ({
    ruleId: r.ruleId,
    description: r.description || '',
    helpUrl: r.helpUrl || '',
    impact: r.impact || 'moderate',
    tags: r.tags || [],
  }))
  .sort((a, b) => a.ruleId.localeCompare(b.ruleId));

const outPath = path.join(__dirname, '..', 'src', 'scanner', 'axeRuleMetadata.json');
fs.writeFileSync(outPath, JSON.stringify(rules, null, 2));
console.log(`Wrote ${rules.length} rules to ${outPath} (axe-core ${axe.version})`);
