# Accessify — VS Code Extension

[![Version](https://img.shields.io/visual-studio-marketplace/v/garvit-magoo.accessify?label=VS%20Marketplace)](https://marketplace.visualstudio.com/items?itemName=garvit-magoo.accessify)
[![Installs](https://img.shields.io/visual-studio-marketplace/i/garvit-magoo.accessify)](https://marketplace.visualstudio.com/items?itemName=garvit-magoo.accessify)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![WCAG 2.1 AA](https://img.shields.io/badge/WCAG-2.1%20AA-blue.svg)](https://www.w3.org/WAI/WCAG21/quickref/)

Accessify brings accessibility testing directly into your VS Code editor. It scans React, JSX, TSX, and HTML files in real time against 17 WCAG 2.1 Level AA rules — every one with an auto-fix — and offers one-click fixes (both deterministic and AI-powered) with confidence scoring and axe-core validation. A built-in screen reader simulator with voice playback lets you hear your UI the way assistive technology users experience it.

## Why Accessify?

Most accessibility tools only catch issues at runtime in the browser. Accessify shifts accessibility left into your editor:

- **Catch issues before code review** — real-time scanning as you type, not after deployment
- **Understand the impact** — every issue links to WCAG criteria, axe-core docs, and impact levels
- **Fix with confidence** — AI-generated fixes show confidence scores so you know what's safe to apply
- **Hear what users hear** — the screen reader preview lets you experience your UI the way assistive technology users do
- **Zero config** — works out of the box with 17 built-in rules; AI features are optional
- **HTML support** — works with plain HTML files in addition to JSX/TSX

## Features

- **Real-time scanning** — Detects accessibility issues as you type with debounced diagnostics
- **17 built-in rules** — Covers WCAG 2.1 Level AA success criteria; every rule has a fix (see [Rules](#rules))
- **Inline diagnostics** — Issues appear as squiggly underlines in the editor
- **Quick Fixes** — Click the lightbulb to apply fixes instantly with confidence % shown in the action title
- **Static Fix Current File** — Preview and apply all deterministic fixes for the current file with a risk-aware preview panel
- **AI-powered fixes** — Optional OpenAI / Azure OpenAI / Claude integration for context-aware fix suggestions
- **AI Fix Entire File** — Let AI fix all issues in a file at once with a diff preview
- **Bulk AI Fix Workspace** — AI-generate fixes for all files in the workspace (scans each file first, skips clean files)
- **AI Fix Caching** — Both single-fix and full-file AI results are cached in-memory (10 min TTL) to avoid redundant API calls
- **Confidence & Reasoning** — Every fix (static and AI) shows a confidence score (0–100%), color-coded risk level, WCAG references, and caveats
- **axe-core Integration** — Fixes are cross-validated against axe-core rule metadata for impact levels, WCAG tags, and documentation links
- **Screen Reader Preview** — Simulates how a screen reader would announce elements, with voice simulation (Web Speech API), per-row playback, speed control, and voice selection
- **Accessibility Score** — Live score (0–100) in the status bar with severity breakdown; click to view report
- **Visual Settings Panel** — Configure rules, AI provider, exclude patterns, and performance settings via a dedicated UI
- **Test Generation** — Auto-generate accessibility test cases from detected issues
- **CI/CD Export** — Export SARIF (for GitHub Code Scanning) or JSON reports
- **Configurable** — Enable/disable rules, set severity overrides, and exclude files via `.a11yrc.json` or the Settings panel
- **Config-aware reports** — Disabled rules and excluded files are respected in reports and exports

## Rules

All 17 rules have both static quick-fixes and AI-powered fixes:

| Rule | WCAG | Severity | Description |
|------|------|----------|-------------|
| `img-alt` | 1.1.1 | Error | `<img>` elements must have an `alt` attribute |
| `button-label` | 4.1.2 | Error | Buttons must have accessible names (`aria-label`, text, etc.) |
| `aria-role` | 4.1.2 | Error | ARIA `role` values must be valid WAI-ARIA roles |
| `form-label` | 1.3.1 | Warning | Form inputs must have associated labels |
| `click-events-have-key-events` | 2.1.1 | Warning | Non-interactive elements with `onClick` need keyboard handlers |
| `aria-pattern` | 4.1.2 | Error | ARIA widget patterns must be correctly structured |
| `color-contrast` | 1.4.3 | Warning | Inline and Tailwind styles must meet WCAG AA contrast ratio |
| `heading-order` | 1.3.1 | Warning | Heading levels must follow a logical hierarchy |
| `autocomplete-valid` | 1.3.5 | Warning | Personal data inputs must have valid `autoComplete` |
| `no-mouse-only-hover` | 1.4.13 | Warning | Hover content must also be keyboard-accessible |
| `no-autofocus` | 2.4.3 | Warning | `autoFocus` can disorient screen reader users on page load |
| `interactive-supports-focus` | 2.1.1 | Warning | Interactive elements must be focusable for keyboard users |
| `no-noninteractive-element-interactions` | 4.1.2 | Warning | Non-interactive elements should not have event handlers |
| `svg-has-accessible-name` | 1.1.1 | Warning | SVG elements must have a `<title>`, `aria-label`, or `aria-labelledby` |
| `nextjs-image-alt` | 1.1.1 | Error | Next.js `<Image>` must have an `alt` attribute |
| `nextjs-head-lang` | 3.1.1 | Error | Next.js `<Html>` must have a `lang` attribute |
| `nextjs-link-text` | 1.1.1 | Warning | Next.js `<Link>` must have discernible text |

## Getting Started

### Install from Marketplace

Search for **Accessify** in the VS Code Extensions panel, or run:

```bash
code --install-extension garvit-magoo.accessify
```

### Install from VSIX

```bash
code --install-extension accessify-1.0.0.vsix
```

### Usage

1. Open any `.tsx`, `.jsx`, or `.html` file — issues appear inline automatically
2. Hover over a squiggly underline to see the issue detail and WCAG reference
3. Click the lightbulb (or press `Ctrl+.`) to see Quick Fix options with confidence scores
4. Click the score in the status bar to view the full accessibility report
5. Use keyboard shortcuts for fast access (see below)

## Commands

Open the Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`) and type `Accessify`:

| Command | Description |
|---------|-------------|
| **Accessify: Show Accessibility Report** | Open the visual report panel (file or workspace) |
| **Accessify: Screen Reader Preview** | Simulate screen reader announcements with voice playback |
| **Accessify: Static Fix Current File** | Preview and apply all static fixes for the current file |
| **Accessify: AI Fix Entire File** | AI-generated fixes for all issues (requires AI provider) |
| **Accessify: Bulk AI Fix Workspace** | AI-fix all files in the workspace (scans first, skips clean files) |
| **Accessify: Static Fix Workspace** | Apply static fixes across the entire workspace |
| **Accessify: Generate A11y Unit Tests** | Auto-generate test cases from detected issues |
| **Accessify: Export Report** | Export SARIF or JSON for CI/CD integration |
| **Accessify: Open Settings** | Visual settings panel for rules, AI, and preferences |
| **Accessify: Set AI API Key** | Store your API key securely |

## Keyboard Shortcuts

| Shortcut | Command |
|----------|---------|
| `Ctrl+Alt+R` (`Cmd+Alt+R`) | Show Report |
| `Ctrl+Alt+F` (`Cmd+Alt+F`) | Static Fix Current File |

## Configuration

### Visual Settings Panel

Run **Accessify: Open Settings** from the Command Palette to configure everything via a visual UI — AI provider, model, rule toggles, exclude patterns, and performance tuning.

### VS Code Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `a11y.scanOnSave` | `true` | Auto-scan on file save |
| `a11y.scanOnOpen` | `true` | Auto-scan when a file is opened |
| `a11y.severity` | `"warning"` | Default diagnostic severity |
| `a11y.aiProvider` | `"none"` | AI provider: `"none"`, `"openai"`, `"azure-openai"`, `"claude"` |
| `a11y.aiEndpoint` | `""` | Azure OpenAI endpoint URL |
| `a11y.aiModel` | `""` | Model name (auto-detected per provider if empty) |
| `a11y.aiBatchConcurrency` | `10` | Files processed in parallel during bulk AI fix (1–10) |
| `a11y.scanConcurrency` | `8` | Files scanned in parallel during workspace scans (1–32) |

### Enable AI Fixes

1. Run **Accessify: Set AI API Key** from the Command Palette to store your key securely
2. Set the provider in settings (or use the Settings panel):

```json
{
  "a11y.aiProvider": "openai"
}
```

For Azure OpenAI, also set the endpoint:

```json
{
  "a11y.aiProvider": "azure-openai",
  "a11y.aiEndpoint": "https://your-resource.openai.azure.com",
  "a11y.aiModel": "your-deployment-name"
}
```

For Claude (Anthropic):

```json
{
  "a11y.aiProvider": "claude"
}
```

### Project-Level Config (`.a11yrc.json`)

Create a `.a11yrc.json` in your workspace root to customize rules and exclusions:

```json
{
  "rules": {
    "color-contrast": { "severity": "error" },
    "heading-order": false
  },
  "exclude": [
    "**/test/**",
    "**/storybook/**"
  ],
  "aiExclude": [
    "**/legacy/**"
  ]
}
```

Disabled rules are excluded from diagnostics, reports, and CI/CD exports.

## CI/CD Integration

Export a SARIF report and upload it to GitHub Code Scanning:

```yaml
# .github/workflows/a11y.yml
- name: Upload SARIF
  uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: a11y-report.sarif
```

## Development

```bash
git clone https://github.com/garvit-magoo/accessify.git
cd accessify
npm install
npm run compile
```

Press `F5` in VS Code to launch the Extension Development Host.

### Run Tests

```bash
npm test
```

### Package

```bash
npx @vscode/vsce package
```

## Architecture

```
src/
├── extension.ts          # Extension entry point, command registration
├── diagnostics.ts        # Real-time diagnostic pipeline
├── codeActions.ts        # Quick fixes, static fix, AI fix commands
├── config.ts             # .a11yrc.json loader with caching
├── statusBar.ts          # Accessibility score status bar item
├── types.ts              # Shared type definitions
├── ai/
│   ├── caller.ts         # Shared AI API caller with retry/backoff
│   ├── provider.ts       # Single-issue AI fix with caching
│   └── fullFileFix.ts    # Full-file AI fix with caching
├── scanner/
│   ├── astScanner.ts     # AST walker, rule orchestration
│   ├── axeIntegration.ts # axe-core metadata, fix validation
│   ├── jsxValidator.ts   # JSX syntax validation
│   └── rules/            # 17 individual rule checkers
└── webview/
    ├── reportPanel.ts    # Accessibility report panel
    ├── diffPreviewPanel.ts       # AI fix diff preview
    ├── bulkFixPreviewPanel.ts    # Bulk fix preview
    ├── screenReaderPanel.ts      # Screen reader simulator
    ├── configPanel.ts    # Visual settings panel
    └── utils.ts          # Shared webview utilities
```

## License

[MIT](LICENSE)
